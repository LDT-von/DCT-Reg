DCT v2.3 scoped candidate delivery, 2026-10-15

Requires the existing independent DCT v2.1 project and its Python dependencies.
This is an additive delivery, not a full repository or trained checkpoint.

1. Extract this package beside the server project.
2. Check first:
   python dct_v23_delivery_20261015/install_candidate.py --project /data1/DCT-Reg --check
3. Install after a successful check:
   python dct_v23_delivery_20261015/install_candidate.py --project /data1/DCT-Reg --apply

The installer checks all payload SHA-256 hashes, refuses conflicting new files,
and backs up shared source and AGENTS.md before applying scoped patches.
It starts no patient calibration, training, evaluation or inference jobs.
The Word method note contains the manually executed experiment commands.
Adapt data paths, result paths and GPU selection to the server before running.

Three matched arms: off, masked_plain, gain_calibrated.
199 focused synthetic checks passed. Patient performance remains unmeasured.
Novelty is a candidate claim; no global-first or score-improvement guarantee.
