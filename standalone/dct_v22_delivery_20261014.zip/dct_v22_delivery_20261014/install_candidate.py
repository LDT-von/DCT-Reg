"""Check/apply the scoped v22 delivery; never start a patient job."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess


def within(root, relative):
    part = PurePosixPath(relative)
    if part.is_absolute() or ".." in part.parts:
        raise ValueError("Invalid relative path")
    target = root.joinpath(*part.parts).resolve()
    if not target.is_relative_to(root):
        raise ValueError("Target escapes project")
    return target


def git_check(project, patch, reverse=False):
    # Context-only whitespace tolerance accommodates Windows CRLF backups.
    # Non-whitespace code changes still fail; no reject/force mode is used.
    command = ["git", "apply", "--ignore-space-change", "--check"]
    if reverse:
        command.append("--reverse")
    command.append(str(patch))
    return subprocess.run(command, cwd=project, capture_output=True, text=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--apply", action="store_true", help="Apply after conflict checks and backups")
    parser.add_argument("--check", action="store_true", help="Check only (default)")
    args = parser.parse_args()
    if args.apply and args.check:
        parser.error("Choose --check or --apply")
    project = args.project.resolve(strict=True)
    if not (project / "survot_rank/research/methods/dct_v21/model.py").is_file():
        raise ValueError("An existing independent DCT v2.1 checkout is required")
    bundle = Path(__file__).resolve().parent
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    for entry in manifest["payload"]:
        source = within(bundle, entry["bundle_path"])
        if hashlib.sha256(source.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError("Bundle integrity failed: " + entry["bundle_path"])
    patch = bundle / "integration.patch"
    for relative in manifest["shared_files"]:
        within(project, relative)
    new_files = []
    for relative in manifest["new_files"]:
        target = within(project, relative)
        source = within(bundle, "new_files/" + relative)
        if target.exists() and target.read_bytes() != source.read_bytes():
            raise FileExistsError("Existing material preserved: " + str(target))
        new_files.append((source, target))
    check = git_check(project, patch)
    already_patched = False
    if check.returncode:
        reverse = git_check(project, patch, reverse=True)
        if reverse.returncode:
            raise RuntimeError("Integration conflict; no files changed:\n" + check.stderr)
        already_patched = True
    section = (bundle / "agents_section.txt").read_text(encoding="utf-8")
    agents = within(project, "AGENTS.md")
    prior_agents = agents.read_text(encoding="utf-8") if agents.exists() else ""
    marker = section.splitlines()[0]
    if marker in prior_agents and section.strip() not in prior_agents:
        raise RuntimeError("Existing v22 instructions differ; no files changed")
    report = {"project": str(project), "integration_already_applied": already_patched,
              "new_files_needed": sum(not target.exists() for _, target in new_files),
              "patient_jobs_started": False}
    if not args.apply:
        report["status"] = "check_passed_no_changes"
        print(json.dumps(report, ensure_ascii=False))
        return
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
    backup = within(project, "docs/history/dct_v22_install_" + stamp)
    backup.mkdir(parents=True, exist_ok=False)
    backup_paths = list(manifest["shared_files"]) + (["AGENTS.md"] if agents.exists() else [])
    for relative in backup_paths:
        original = within(project, relative)
        if original.exists():
            destination = within(backup, relative)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(original, destination)
    if not already_patched:
        subprocess.run(["git", "apply", "--ignore-space-change", str(patch)], cwd=project, check=True)
    for source, target in new_files:
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    if marker not in prior_agents:
        agents.write_text(prior_agents.rstrip() + "\n\n" + section.rstrip() + "\n", encoding="utf-8")
    report.update(status="installed", backup=str(backup))
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
