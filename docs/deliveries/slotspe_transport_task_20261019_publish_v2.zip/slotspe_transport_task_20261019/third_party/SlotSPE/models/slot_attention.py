#!/usr/bin/env python3
# -*- encodinng: uft-8 -*-
'''
@file: slot_attention.py
@author:zyl
@contact:yilan.zhang@kaust.edu.sa
@time:3/8/26 5:20 PM
'''
from __future__ import annotations
import torch
from torch import einsum, nn
from torch.nn import init
from torch.nn import Module
import torch.nn.functional as F

from einops import repeat, pack, unpack
from einops.layers.torch import Rearrange


class MultiHeadSlotAttention(Module):
    def __init__(
            self,
            num_slots,
            dim,
            heads=4,
            dim_head=64,
            iters=3,
            eps=1e-8,
            hidden_dim=128
    ):
        super().__init__()
        self.dim = dim
        self.num_slots = num_slots
        self.iters = iters
        self.eps = eps
        self.scale = dim ** -0.5

        self.slots_mu = nn.Parameter(torch.randn(1, 1, dim))

        self.slots_logsigma = nn.Parameter(torch.zeros(1, 1, dim))
        init.xavier_uniform_(self.slots_logsigma)

        self.norm_input = nn.LayerNorm(dim)
        self.norm_slots = nn.LayerNorm(dim)

        dim_inner = dim_head * heads

        self.split_heads = Rearrange('b n (h d) -> b h n d', h=heads)

        self.to_q = nn.Linear(dim, dim_inner)
        self.to_k = nn.Linear(dim, dim_inner)
        self.to_v = nn.Linear(dim, dim_inner)

        self.merge_heads = Rearrange('b h n d -> b n (h d)')
        self.combine_heads = nn.Linear(dim_inner, dim)

        self.gru = nn.GRUCell(dim, dim)

        hidden_dim = max(dim, hidden_dim)

        self.norm_pre_ff = nn.LayerNorm(dim)

        self.mlp = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, dim)
        )

    def forward(
            self,
            inputs,
            num_slots: int | None = None
    ):
        b, n, d, device, dtype = *inputs.shape, inputs.device, inputs.dtype
        n_s = num_slots if num_slots is not None else self.num_slots

        mu = repeat(self.slots_mu, '1 1 d -> b s d', b=b, s=n_s)
        sigma = repeat(self.slots_logsigma.exp(), '1 1 d -> b s d', b=b, s=n_s)

        slots = mu + sigma * torch.randn(mu.shape, device=device, dtype=dtype)

        inputs = self.norm_input(inputs)

        k, v = self.to_k(inputs), self.to_v(inputs)
        k, v = map(self.split_heads, (k, v))

        for _ in range(self.iters):
            slots_prev = slots

            slots = self.norm_slots(slots)

            q = self.to_q(slots)
            q = self.split_heads(q)

            dots = einsum('... i d, ... j d -> ... i j', q, k) * self.scale

            attn = dots.softmax(dim=-2)
            attn = F.normalize(attn + self.eps, p=1, dim=-1)

            updates = einsum('... j d, ... i j -> ... i d', v, attn)
            updates = self.merge_heads(updates)
            updates = self.combine_heads(updates)

            updates, packed_shape = pack([updates], '* d')
            slots_prev, _ = pack([slots_prev], '* d')

            slots = self.gru(updates, slots_prev)

            slots, = unpack(slots, packed_shape, '* d')
            slots = slots + self.mlp(self.norm_pre_ff(slots))

        return slots

'''
For Diffrentiable Top-k Slot Selection
'''

def log(t, eps=1e-20):
    return torch.log(t.clamp(min=eps))

def gumbel_noise(t):
    noise = torch.rand_like(t)
    return -log(-log(noise))


def relaxed_topk(logits, k, temperature=1.0):
    """
    logits: (B, S)
    returns:
        soft_k_hot: (B, S), approximately sums to k
    """
    scores = logits
    soft_k_hot = torch.zeros_like(logits)

    for _ in range(k):
        probs = F.softmax(scores / temperature, dim=-1)
        soft_k_hot = soft_k_hot + probs

        # suppress mass already assigned in this step
        scores = scores + torch.log((1.0 - probs).clamp(min=1e-20))

    return soft_k_hot


def gumbel_topk_st(logits, k=1, temperature=1.0):
    """
    Standard straight-through Gumbel-TopK.
    forward: hard k-hot
    backward: relaxed top-k
    """
    noised_logits = logits + gumbel_noise(logits)

    topk_indices = noised_logits.topk(k=k, dim=-1).indices

    hard_k_hot = torch.zeros_like(logits)
    hard_k_hot.scatter_(1, topk_indices, 1.0)

    soft_k_hot = relaxed_topk(noised_logits, k=k, temperature=temperature)

    y = hard_k_hot + soft_k_hot - soft_k_hot.detach()
    return y, topk_indices


def parallel_topk_st(logits, k=1, temperature=1.0):
    """
    Parallel approximate top-k relaxation.

    forward:
        hard k-hot from Gumbel-TopK
    backward:
        dense soft surrogate scaled to sum to k
    """
    noised_logits = logits + gumbel_noise(logits)

    topk_indices = noised_logits.topk(k=k, dim=-1).indices

    hard_k_hot = torch.zeros_like(logits)
    hard_k_hot.scatter_(1, topk_indices, 1.0)

    # fully parallel surrogate
    soft = F.softmax(noised_logits / temperature, dim=-1)
    soft_k_hot = k * soft

    y = hard_k_hot + soft_k_hot - soft_k_hot.detach()
    return y, topk_indices
