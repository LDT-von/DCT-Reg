"""Reuse pinned native interfaces without changing or registering a v1 method."""
from typing import Mapping

import torch

from ..transport.native import build_native_adapter
from .config import TransportPluginV2Config
from .plugin import DCTTransportPluginV2


def build_native_adapter_v2(backbone_name, omic_sizes, *, plugin_config=None,
                            reconstruction_config=None, **native_options):
    if plugin_config is None:
        cfg = TransportPluginV2Config(wsi_dim=256, omics_dim=256)
    elif isinstance(plugin_config, TransportPluginV2Config):
        cfg = plugin_config
    elif isinstance(plugin_config, Mapping):
        cfg = TransportPluginV2Config.from_dict({"wsi_dim": 256, "omics_dim": 256, **dict(plugin_config)})
    else:
        raise TypeError("plugin_config must be v2 config or a mapping")
    adapter = build_native_adapter(backbone_name, omic_sizes,
        plugin_config=cfg.legacy_configuration(), reconstruction_config=reconstruction_config, **native_options)
    original = adapter.plugin
    with torch.random.fork_rng(devices=[]):
        plugin = DCTTransportPluginV2(cfg, reconstruction=original.reconstruction)
    # All existing tensors have the same layout. Only plugin metadata is v2.
    tensors = {key: value for key, value in original.state_dict().items() if key != "_extra_state"}
    tensors["_extra_state"] = plugin.get_extra_state()
    plugin.load_state_dict(tensors, strict=True)
    plugin.set_enabled(original.enabled)
    adapter.plugin = plugin
    adapter.native_config["plugin_config"] = cfg.to_dict()
    adapter.source_provenance["plugin_version"] = "transport_plugin_v2"
    adapter.source_provenance["claim"] = "new experimental recipe; no inherited patient score"
    return adapter
