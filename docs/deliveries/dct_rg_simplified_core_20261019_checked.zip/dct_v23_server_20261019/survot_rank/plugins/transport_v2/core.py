"""KL-relaxed transport; unchanged v1 networks, new cost and mass semantics.

The solver minimizes <C,T> + eps KL(T|a b^T) + tau_h KL(T1|a)
                         + tau_g KL(T^T1|b).
No balanced marginal projection is performed after UOT. Independent controls
retain the realized marginals, including their derivatives through the solver.
"""
from dataclasses import dataclass, fields
import math

import torch
from torch.nn import functional as F

from ..transport.core import TransportCore, TransportState, pair_tokens
from .config import TransportPluginV2Config


def realized_independent_plan(plan):
    """Remove topology without changing positive realized mass or marginals."""
    if plan.ndim < 2 or not plan.is_floating_point():
        raise ValueError("plan must be a floating transport matrix")
    if not bool(torch.isfinite(plan).all()) or bool((plan < 0).any()):
        raise ValueError("plan must be finite and nonnegative")
    rows, cols = plan.sum(-1), plan.sum(-2)
    mass = rows.sum(-1)
    safe_mass = torch.where(mass > 0, mass, torch.ones_like(mass))
    # Normalized factors avoid underflow in r*c for very small positive mass.
    return mass[..., None, None] * (rows / safe_mass[..., None])[..., :, None] * (
        cols / safe_mass[..., None])[..., None, :]


@dataclass
class TransportStateV2(TransportState):
    transport_mass: torch.Tensor
    wsi_confidence: torch.Tensor
    omics_confidence: torch.Tensor
    writeback_confidence: torch.Tensor


class TransportCoreV2(TransportCore):
    def __init__(self, config: TransportPluginV2Config):
        if not isinstance(config, TransportPluginV2Config):
            raise TypeError("TransportCoreV2 requires its versioned configuration")
        super().__init__(config)
        self.last_solver_diagnostics = {}

    @classmethod
    def from_dct(cls, model):
        raise ValueError("v2 is a new recipe; construct explicitly, then copy compatible v1 weights")

    def _costs_and_marginals(self, wsi, omics):
        cfg = self.config
        if cfg.cost_mode == "legacy":
            return super()._costs_and_marginals(wsi, omics)
        contents = pair_tokens(wsi, omics)
        stage_cost = torch.sigmoid(self.stage_pair_cost(contents)).permute(0, 3, 1, 2)
        cosine = torch.bmm(F.normalize(wsi, dim=-1), F.normalize(omics, dim=-1).transpose(1, 2))
        distance = torch.cdist(wsi, omics, p=2)
        base = {
            "cosine": (1. - cosine.clamp(-1., 1.)) / 2.,
            # Raw norms remain informative; this is not normalized squared L2,
            # which would be algebraically identical to the cosine branch.
            "euclidean": distance / (distance + cfg.euclidean_scale),
            "positive_dot": torch.sigmoid(-torch.bmm(wsi, omics.transpose(1, 2)) / math.sqrt(cfg.dim)),
        }
        costs, rows, cols = [], [], []
        for stage in range(cfg.stages):
            code = self.stage_embedding[stage].view(1, 1, 1, -1).expand(*contents.shape[:-1], cfg.dim)
            gate = torch.sigmoid(self.evidence_gate(torch.cat((contents, code), -1)).squeeze(-1))
            costs.append(cfg.cost_scale * torch.stack([
                base[name] + cfg.stage_cost_weight * stage_cost[:, stage]
                + cfg.evidence_cost_weight * (1. - gate) for name in cfg.geometries], 1))
            rows.append(gate.mean(-1).clamp_min(cfg.evidence_mass_floor))
            cols.append(gate.mean(-2).clamp_min(cfg.evidence_mass_floor))
        rows, cols = torch.stack(rows, 1), torch.stack(cols, 1)
        rows, cols = rows / rows.sum(-1, keepdim=True), cols / cols.sum(-1, keepdim=True)
        strength = cfg.marginal_strength
        return torch.stack(costs, 1), ((1.-strength) / rows.size(-1) + strength * rows), (
            (1.-strength) / cols.size(-1) + strength * cols)

    def plans_from_costs(self, costs, rows, cols, epoch):
        cfg = self.config
        if cfg.transport_mode == "balanced":
            self.last_solver_diagnostics = {"mode": "balanced", "actual_marginal_control": False}
            return super().plans_from_costs(costs, rows, cols, epoch)
        if self.plan_mode not in {"learned", "independent"}:
            raise ValueError("v2 plan_mode must be learned or independent")
        if costs.ndim != 5 or rows.shape != (costs.size(0), costs.size(1), costs.size(3)) or (
            cols.shape != (costs.size(0), costs.size(1), costs.size(4))):
            raise ValueError("expected costs [B,S,G,W,O], rows [B,S,W], cols [B,S,O]")
        if not bool(torch.isfinite(costs).all()) or not bool(torch.isfinite(rows).all()) or not bool(
            torch.isfinite(cols).all()) or bool((rows <= 0).any()) or bool((cols <= 0).any()):
            raise ValueError("costs must be finite and reference marginals finite and strictly positive")
        dtype = torch.float64 if costs.dtype == torch.float64 else torch.float32
        with torch.autocast(device_type=costs.device.type, enabled=False):
            c, a, b = costs.to(dtype), rows.to(dtype), cols.to(dtype)
            a, b = a / a.sum(-1, keepdim=True), b / b.sum(-1, keepdim=True)
            log_a, log_b = a.log().unsqueeze(2), b.log().unsqueeze(2)
            eps = self.epsilon(epoch)
            log_kernel = log_a[..., :, None] + log_b[..., None, :] - c / eps
            theta_h, theta_g = cfg.tau_wsi / (cfg.tau_wsi + eps), cfg.tau_omics / (cfg.tau_omics + eps)
            u, v = torch.zeros_like(log_kernel[..., 0]), torch.zeros_like(log_kernel[..., 0, :])
            effective_tolerance = max(cfg.uot_tolerance, 8. * torch.finfo(dtype).eps)
            potential_scale = 1.
            change = float("inf")
            for iteration in range(cfg.uot_iters):
                old_u, old_v = u, v
                u = theta_h * (log_a - torch.logsumexp(log_kernel + v[..., None, :], -1))
                v = theta_g * (log_b - torch.logsumexp(log_kernel + u[..., :, None], -2))
                if (iteration + 1) % 10 == 0 or iteration + 1 == cfg.uot_iters:
                    potential_scale = float(torch.maximum(u.abs().amax(), v.abs().amax()).detach().clamp_min(1.))
                    effective_tolerance = max(cfg.uot_tolerance, 8. * torch.finfo(dtype).eps * potential_scale)
                    change = torch.maximum((u-old_u).abs().amax(), (v-old_v).abs().amax()).detach()
                    if bool(change <= effective_tolerance):
                        break
            if not bool(change <= effective_tolerance):
                raise RuntimeError("UOT did not converge within uot_iters; increase the budget or recalibrate tau/eps")
            plan = (log_kernel + u[..., :, None] + v[..., None, :]).exp()
            if not bool(torch.isfinite(plan).all()):
                raise RuntimeError("UOT produced a nonfinite plan; check cost/tau/eps scales")
            self.last_solver_diagnostics = {"mode": "uot", "iterations": iteration + 1,
                "max_log_update": float(change), "effective_tolerance": effective_tolerance,
                "requested_tolerance": cfg.uot_tolerance, "max_log_potential": potential_scale,
                "converged": True,
                "actual_marginal_control": self.plan_mode == "independent"}
            if self.plan_mode == "independent":
                plan = realized_independent_plan(plan)
            return plan, a, b

    def forward(self, wsi, omics, *, wsi_mask, omics_mask, epoch=0):
        # v1 dispatches to this version's cost and solver methods. It still owns
        # slot extraction and event networks, so their parameter layout is fixed.
        state = super().forward(wsi, omics, wsi_mask=wsi_mask, omics_mask=omics_mask, epoch=epoch)
        consensus = state.plans.mean(2)
        actual_rows, actual_cols = consensus.sum(-1), consensus.sum(-2)
        mass = actual_rows.sum(-1)
        a, b = state.row_marginals, state.col_marginals
        safe_a = torch.where(a > 0, a, torch.ones_like(a))
        safe_b = torch.where(b > 0, b, torch.ones_like(b))
        row_gate, col_gate = (actual_rows / safe_a).clamp(0., 1.), (actual_cols / safe_b).clamp(0., 1.)
        weights = state.stage_weights.to(mass.dtype)
        wsi_confidence = torch.einsum("bs,bsw->bw", weights.detach(), row_gate)
        omics_confidence = torch.einsum("bs,bso->bo", weights.detach(), col_gate)
        confidence = (weights * mass.clamp(0., 1.)).sum(-1)
        values = {field.name: getattr(state, field.name) for field in fields(TransportState)}
        if self.config.mass_aware:
            # Gate BEFORE averaging stages: a well-matched stage must not
            # lend its strength to the normalized feature of a weak stage.
            with torch.autocast(device_type=wsi.device.type, enabled=False):
                moved_wsi = torch.einsum("bswo,bwd->bsod", consensus, state.wsi_slots.to(consensus.dtype))
                moved_omics = torch.einsum("bswo,bod->bswd", consensus, state.omics_slots.to(consensus.dtype))
                moved_wsi = moved_wsi / actual_cols[..., None].clamp_min(1e-8)
                moved_omics = moved_omics / actual_rows[..., None].clamp_min(1e-8)
                values["transported_wsi"] = torch.einsum(
                    "bs,bsod->bod", weights.detach(), moved_wsi * col_gate[..., None]).to(wsi.dtype)
                values["transported_omics"] = torch.einsum(
                    "bs,bswd->bwd", weights.detach(), moved_omics * row_gate[..., None]).to(omics.dtype)
        return TransportStateV2(**values, transport_mass=mass, wsi_confidence=wsi_confidence,
                                omics_confidence=omics_confidence, writeback_confidence=confidence)
