"""Version 2 residual updates explicitly retain realized matching strength."""
import torch

from ..transport.plugin import DCTTransportPlugin, TransportPluginOutput
from .config import TransportPluginV2Config
from .core import TransportCoreV2


class DCTTransportPluginV2(DCTTransportPlugin):
    def __init__(self, config: TransportPluginV2Config, reconstruction=None):
        if not isinstance(config, TransportPluginV2Config):
            raise TypeError("v2 requires TransportPluginV2Config")
        super().__init__(config, reconstruction)
        # Identical initialization and RNG state across v1/v2 and all v2 arms.
        with torch.random.fork_rng(devices=[]):
            core = TransportCoreV2(config)
        core.load_state_dict(self.core.state_dict(), strict=True)
        self.core = core
        self.last_diagnostics = {}
        self.last_encoded_inputs = None

    def set_plan_mode(self, mode):
        # Validate before the inherited setter can mutate core.plan_mode.
        if mode not in {"learned", "independent"}:
            raise ValueError("v2 plan mode must be learned or independent")
        return super().set_plan_mode(mode)

    def get_extra_state(self):
        return {"schema": "dct_transport_plugin_v2", "config": self.config.to_dict(), "enabled": self.enabled}

    def set_extra_state(self, state):
        if not isinstance(state, dict) or state.get("schema") != "dct_transport_plugin_v2":
            raise ValueError("v2 requires version-2 checkpoint metadata")
        saved = TransportPluginV2Config.from_dict(state["config"])
        if saved.to_dict() != self.config.to_dict():
            raise ValueError("construct v2 from the exact checkpoint configuration before loading")
        self.set_enabled(state["enabled"])

    def forward(self, wsi, omics, *, wsi_mask=None, omics_mask=None, epoch=0,
                compute_aux=None, enabled=None):
        # The v2 task objective replays frozen encoded inputs and a controlled
        # plan through the existing host. This internal override is eval-only;
        # ordinary training/inference always computes its own factual state.
        override = getattr(self, "_task_state_override", None)
        if override is not None:
            if self.training:
                raise RuntimeError("controlled v2 task readout must run in eval mode")
            wsi, omics = self._task_encoded_inputs
        if wsi.ndim != 3 or omics.ndim != 3 or wsi.size(0) != omics.size(0) or wsi.size(0) < 1:
            raise ValueError("expected paired [B,N,Dh] and [B,P,Dg] tensors")
        if wsi.size(-1) != self.config.wsi_dim or omics.size(-1) != self.config.omics_dim:
            raise ValueError("feature dimensions do not match version-2 config")
        if wsi.device != omics.device or wsi.dtype != omics.dtype or not wsi.is_floating_point():
            raise ValueError("paired features require the same floating dtype/device")
        if not isinstance(epoch, int) or isinstance(epoch, bool) or epoch < 0:
            raise ValueError("epoch must be a nonnegative integer")
        active = self.enabled if enabled is None else enabled
        if not isinstance(active, bool):
            raise TypeError("enabled must be bool")
        zero = wsi.new_zeros(()) + self.wsi_gain.to(wsi.device) * 0.
        if not active:
            result = TransportPluginOutput(wsi, omics, zero)
            self.last_output, self.last_diagnostics = result, {"enabled": False}
            self.last_encoded_inputs = None
            return result
        wm, om = self._mask(wsi, wsi_mask, "wsi_mask"), self._mask(omics, omics_mask, "omics_mask")
        safe_wsi, safe_omics = wsi.masked_fill(~wm[..., None], 0.), omics.masked_fill(~om[..., None], 0.)
        h, g = self.wsi_projection(safe_wsi), self.omics_projection(safe_omics)
        h, g = h.masked_fill(~wm[..., None], 0.), g.masked_fill(~om[..., None], 0.)
        self.last_encoded_inputs = (safe_wsi, safe_omics)
        state = override if override is not None else self.core(h, g, wsi_mask=wm, omics_mask=om, epoch=epoch)
        out_wsi, out_omics = safe_wsi, safe_omics
        if bool(state.pair_available.any()):
            ids = state.pair_available.nonzero(as_tuple=True)[0]
            events = state.event_tokens[ids] * state.stage_weights[ids, :, None]
            w_context = torch.cat((events, state.transported_omics[ids]), 1)
            g_context = torch.cat((events, state.transported_wsi[ids]), 1)
            w_update, _ = self.wsi_writeback(self.wsi_query_norm(h[ids]), w_context, w_context, need_weights=False)
            g_update, _ = self.omics_writeback(self.omics_query_norm(g[ids]), g_context, g_context, need_weights=False)
            w_update = self.wsi_output_projection(w_update).to(wsi.dtype)
            g_update = self.omics_output_projection(g_update).to(omics.dtype)
            if self.config.mass_aware:
                # AFTER LayerNorm, attention and biased output projections.
                # Even a zero plan cannot regenerate an update through biases.
                strength = state.writeback_confidence[ids, None, None]
                w_update, g_update = w_update * strength.to(wsi.dtype), g_update * strength.to(omics.dtype)
            w_update = w_update.masked_fill(~wm[ids, :, None], 0.)
            g_update = g_update.masked_fill(~om[ids, :, None], 0.)
            out_wsi = out_wsi.index_add(0, ids, torch.tanh(self.wsi_gain) * w_update)
            out_omics = out_omics.index_add(0, ids, torch.tanh(self.omics_gain) * g_update)
        aux, losses = zero, {}
        if self.training and compute_aux is not False and self.reconstruction is not None:
            aux, losses = self.reconstruction(state, epoch=epoch)
            aux = aux + zero
        result = TransportPluginOutput(out_wsi, out_omics, aux, losses, state)
        with torch.no_grad():
            a, b = state.row_marginals, state.col_marginals
            r, c = state.plans.mean(2).sum(-1), state.plans.mean(2).sum(-2)
            self.last_diagnostics = {
                "schema": "transport_plugin_v2_diagnostics_v1", "enabled": True,
                "transport_mode": self.config.transport_mode, "plan_mode": self.core.plan_mode,
                "explicit_mass_gate": self.config.mass_aware,
                "total_mass_mean": float(state.transport_mass.mean()),
                "total_mass_min": float(state.transport_mass.min()),
                "total_mass_max": float(state.transport_mass.max()),
                "reference_min": float(torch.minimum(a[a>0].min(), b[b>0].min())) if bool((a>0).any()) else 0.,
                "row_budget_overflow_fraction": float((r > a + 1e-6).float().mean()),
                "column_budget_overflow_fraction": float((c > b + 1e-6).float().mean()),
                "writeback_strength_mean": float(state.writeback_confidence.mean()),
                "wsi_residual_gain": float(torch.tanh(self.wsi_gain)),
                "omics_residual_gain": float(torch.tanh(self.omics_gain)),
                "wsi_delta_norm": float((out_wsi-safe_wsi).norm(dim=-1).mean()),
                "omics_delta_norm": float((out_omics-safe_omics).norm(dim=-1).mean()),
                "solver": dict(self.core.last_solver_diagnostics),
            }
        self.last_output = result
        return result
