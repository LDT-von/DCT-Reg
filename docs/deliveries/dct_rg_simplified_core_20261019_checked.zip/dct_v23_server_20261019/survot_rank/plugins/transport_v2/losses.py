"""Two v2-only training objectives; no extra inference network or decoder.

The relation term conditions on detached REALIZED margins and freezes all
readout weights. Only pair-cost parameters receive its gradients. The native
term supervises the existing host with plugin writeback bypassed and a detached
reference-deficit weight. The caller supplies the same censored survival loss
used by its main objective; this module never infers labels.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, dataclass, fields
import math
from typing import Callable

import torch
from torch import Tensor, nn
from torch.func import functional_call

from .core import TransportStateV2, realized_independent_plan


@dataclass(frozen=True)
class TransportV2TaskLossConfig:
    relation_weight: float = .05
    native_weight: float = .05
    relation_tolerance: float = 0.
    relation_warmup_epochs: int = 3
    relation_ramp_epochs: int = 5
    projection_iters: int = 1000
    projection_tolerance: float = 1e-6
    min_plan_mass: float = 1e-8

    def __post_init__(self):
        for name in ("relation_weight", "native_weight", "relation_tolerance", "min_plan_mass"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                raise ValueError(f"{name} must be finite and nonnegative")
        for name in ("relation_warmup_epochs", "relation_ramp_epochs", "projection_iters"):
            value = getattr(self, name)
            minimum = 0 if name == "relation_warmup_epochs" else 1
            if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
                raise ValueError(f"{name} must be an integer >= {minimum}")
        value = self.projection_tolerance
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError("projection_tolerance must be finite and positive")

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, values):
        if not isinstance(values, dict):
            raise ValueError("v2 task-loss configuration must be an object")
        return cls(**values)

    def relation_effective_weight(self, epoch):
        if isinstance(epoch, bool) or not isinstance(epoch, int) or epoch < 0:
            raise ValueError("epoch must be a nonnegative integer")
        ramp = min(1., max(0., (epoch - self.relation_warmup_epochs + 1) / self.relation_ramp_epochs))
        return self.relation_weight * ramp


@dataclass
class TransportV2TaskLossOutput:
    loss: Tensor
    terms: dict[str, Tensor]
    diagnostics: dict


def fixed_realized_marginal_plan(costs: Tensor, rows: Tensor, cols: Tensor, *,
                                 epsilon: float, iterations: int = 1000,
                                 tolerance: float = 1e-6, min_mass: float = 1e-8) -> Tensor:
    """Differentiable entropy projection with detached actual margins.

    Row/column factors in the KL reference can be absorbed by dual scalings at
    fixed margins, so the kernel exp(-C/epsilon) has the same minimizer. Tiny
    positive masses below min_mass retain an independent feasible plan and have
    zero cost gradient; zero rows/columns remain exactly zero. A failed active
    solve raises instead of silently substituting another matching mechanism.
    """
    if (costs.ndim != 5 or rows.shape != costs.shape[:3] + costs.shape[3:4]
            or cols.shape != costs.shape[:3] + costs.shape[4:5]):
        raise ValueError("expected costs [B,S,G,W,O], actual rows [B,S,G,W], cols [B,S,G,O]")
    for name, value, positive in (("epsilon", epsilon, True), ("tolerance", tolerance, True), ("min_mass", min_mass, False)):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or (value <= 0 if positive else value < 0):
            raise ValueError(f"invalid {name}")
    if isinstance(iterations, bool) or not isinstance(iterations, int) or iterations < 1:
        raise ValueError("iterations must be positive")
    if not all(value.is_floating_point() and value.device == costs.device for value in (costs, rows, cols)):
        raise ValueError("costs and margins require floating tensors on the same device")
    if not all(bool(torch.isfinite(value).all()) for value in (costs, rows, cols)) or bool((rows < 0).any()) or bool((cols < 0).any()):
        raise ValueError("costs must be finite and actual margins finite/nonnegative")
    dtype = torch.float64 if costs.dtype == torch.float64 else torch.float32
    with torch.autocast(device_type=costs.device.type, enabled=False):
        c = costs.to(dtype).reshape(-1, costs.size(-2), costs.size(-1))
        r = rows.detach().to(dtype).reshape(-1, costs.size(-2))
        o = cols.detach().to(dtype).reshape(-1, costs.size(-1))
        mass_r, mass_o = r.sum(-1), o.sum(-1)
        if not bool(torch.isfinite(mass_r).all()) or not bool(torch.isfinite(mass_o).all()):
            raise ValueError("actual total mass must be finite")
        mass_scale = torch.maximum(mass_r, mass_o)
        safe_scale = torch.where(mass_scale > 0, mass_scale, torch.ones_like(mass_scale))
        relative_mass_error = (mass_r-mass_o).abs() / safe_scale
        if bool(((mass_r > 0) != (mass_o > 0)).any()) or bool((relative_mass_error > 1e-5).any()):
            raise ValueError("actual row and column mass must agree")
        safe_r = torch.where(mass_r > 0, mass_r, torch.ones_like(mass_r))
        safe_o = torch.where(mass_o > 0, mass_o, torch.ones_like(mass_o))
        rn, on = r / safe_r[:, None], o / safe_o[:, None]
        result = (mass_r[:, None, None] * rn[:, :, None] * on[:, None, :]).detach() + c * 0.
        active = (mass_r > min_mass).nonzero(as_tuple=True)[0]
        if active.numel():
            rr, oo = rn[active], on[active]
            kernel = -c[active] / epsilon
            # A constant offset is valid HERE because actual total mass is fixed.
            kernel = kernel - kernel.amax((-2, -1), keepdim=True).detach()
            tiny = torch.finfo(dtype).tiny
            log_r, log_o = rr.clamp_min(tiny).log(), oo.clamp_min(tiny).log()
            u = torch.where(rr > 0, torch.zeros_like(rr), torch.full_like(rr, -torch.inf))
            v = torch.where(oo > 0, torch.zeros_like(oo), torch.full_like(oo, -torch.inf))
            effective = max(tolerance, 8 * torch.finfo(dtype).eps)
            error = math.inf
            for iteration in range(iterations):
                next_u = log_r - torch.logsumexp(kernel + v[:, None, :], -1)
                u = torch.where(rr > 0, next_u, torch.full_like(next_u, -torch.inf))
                next_v = log_o - torch.logsumexp(kernel + u[:, :, None], -2)
                v = torch.where(oo > 0, next_v, torch.full_like(next_v, -torch.inf))
                if (iteration + 1) % 10 == 0 or iteration + 1 == iterations:
                    q = (kernel + u[:, :, None] + v[:, None, :]).exp()
                    error = torch.maximum((q.sum(-1) - rr).abs().amax(), (q.sum(-2) - oo).abs().amax()).detach()
                    if bool(error <= effective):
                        break
            if not bool(error <= effective):
                raise RuntimeError("fixed-realized-marginal projection did not converge")
            plan = q * mass_r[active, None, None]
            if not bool(torch.isfinite(plan).all()):
                raise RuntimeError("fixed-realized-marginal projection produced nonfinite values")
            result = result.index_copy(0, active, plan)
        return result.reshape_as(costs)


def reference_deficit(state: TransportStateV2) -> Tensor:
    """Detached reference-budget deficit, not a biological private-information probability."""
    plans = state.plans.detach()
    rows, cols = plans.sum(-1), plans.sum(-2)
    a, b = state.row_marginals.detach().unsqueeze(2), state.col_marginals.detach().unsqueeze(2)
    deficit = .5 * ((a-rows).clamp_min(0.).sum(-1) + (b-cols).clamp_min(0.).sum(-1))
    value = (state.stage_weights.detach().to(deficit.dtype) * deficit.mean(2)).sum(-1)
    return value.clamp(0., 1.).detach()


class _EventReader(nn.Module):
    def __init__(self, core):
        super().__init__()
        self.core = core

    def forward(self, wsi, omics, plan):
        return self.core.events_from_plans(wsi, omics, plan)[0]


def _frozen_weights(module):
    return ({name: value.detach() for name, value in module.named_parameters()},
            {name: value.detach() for name, value in module.named_buffers()})


def _controlled_state(core, original, plan):
    readout_dtype = next(core.parameters()).dtype
    values = {}
    for field in fields(TransportStateV2):
        value = getattr(original, field.name).detach()
        values[field.name] = value.to(readout_dtype) if value.is_floating_point() else value
    sw, so = values["wsi_slots"], values["omics_slots"]
    values["plans"] = plan
    reader = _EventReader(core)
    values["event_tokens"] = functional_call(reader, _frozen_weights(reader), (sw, so, plan))
    # Keep factual stage weights, realized margins and all quality gates fixed.
    reference = original.plans.detach().mean(2)
    rows, cols = reference.sum(-1), reference.sum(-2)
    a, b = values["row_marginals"], values["col_marginals"]
    row_gate = (rows / torch.where(a > 0, a, torch.ones_like(a))).clamp(0., 1.)
    col_gate = (cols / torch.where(b > 0, b, torch.ones_like(b))).clamp(0., 1.)
    consensus = plan.mean(2)
    with torch.autocast(device_type=plan.device.type, enabled=False):
        w = torch.einsum("bswo,bwd->bsod", consensus, sw.to(plan.dtype)) / cols[..., None].clamp_min(1e-8)
        o = torch.einsum("bswo,bod->bswd", consensus, so.to(plan.dtype)) / rows[..., None].clamp_min(1e-8)
        if core.config.mass_aware:
            w, o = w * col_gate[..., None], o * row_gate[..., None]
        pi = values["stage_weights"].to(plan.dtype)
        values["transported_wsi"] = torch.einsum("bs,bsod->bod", pi, w).to(sw.dtype)
        values["transported_omics"] = torch.einsum("bs,bswd->bwd", pi, o).to(so.dtype)
    return TransportStateV2(**values)


@contextmanager
def _preserve_forward_state(model):
    flags = [(module, module.training) for module in model.modules()]
    missing = object()
    saved = [(model, "last_plugin_output", getattr(model, "last_plugin_output", missing))]
    for name in ("last_output", "last_diagnostics", "last_encoded_inputs", "_task_state_override", "_task_encoded_inputs"):
        saved.append((model.plugin, name, getattr(model.plugin, name, missing)))
    try:
        yield flags
    finally:
        for module, training in flags:
            module.training = training
        for module, name, value in saved:
            if value is missing:
                if hasattr(module, name):
                    delattr(module, name)
            else:
                setattr(module, name, value)


def _prediction(output, backbone_name):
    value = output[0] if backbone_name == "mcat" else output
    if not torch.is_tensor(value) or value.ndim != 2 or not value.is_floating_point() or not bool(torch.isfinite(value).all()):
        raise ValueError("v2 task objective requires finite native prediction [B,K]")
    return value


def _criterion(callback, prediction):
    loss = callback(prediction)
    if not torch.is_tensor(loss) or loss.ndim != 0 or not bool(torch.isfinite(loss)):
        raise ValueError("survival_loss must return one finite scalar")
    return loss


def compute_transport_v2_task_losses(model, native_inputs: dict,
                                     config: TransportV2TaskLossConfig,
                                     survival_loss: Callable[[Tensor], Tensor], *,
                                     backbone_name: str, epoch: int = 0) -> TransportV2TaskLossOutput:
    """Call after factual training forward; all auxiliary state is restored.

    Relation readout is deterministic/eval with detached parameters and cached
    encoded features. Auxiliary arithmetic uses the corresponding weight dtype
    with autocast disabled, including after a mixed-precision factual forward.
    Native supervision keeps the caller's training mode. No
    survival callback or extra host forward is run when disabled or in eval.
    """
    if not isinstance(config, TransportV2TaskLossConfig):
        raise TypeError("v2 task losses require TransportV2TaskLossConfig")
    if backbone_name not in {"mcat", "survpath"}:
        raise ValueError("supported native host names: mcat, survpath")
    rw, nw = config.relation_effective_weight(epoch), config.native_weight
    zero = model.plugin.wsi_gain.new_zeros(())
    terms = {name: zero for name in ("relation_raw", "relation_weighted", "native_raw", "native_weighted", "reference_deficit")}
    diagnostics = {"relation_effective_weight": rw, "native_effective_weight": nw,
                   "training_only": True, "relation_eligible_plans": 0}
    if not model.training or (rw == 0 and nw == 0):
        diagnostics["skipped"] = "eval" if not model.training else "zero_effective_weights"
        return TransportV2TaskLossOutput(zero, terms, diagnostics)
    state = getattr(getattr(model.plugin, "last_output", None), "transport", None)
    inputs = model.plugin.last_encoded_inputs
    if not isinstance(state, TransportStateV2) or inputs is None:
        raise ValueError("v2 task loss requires a preceding factual v2 forward")
    if state.plans.size(0) != 1:
        raise ValueError("these native task-loss interfaces require one patient per forward")
    if model.plugin.core.config.transport_mode != "uot" or model.plugin.core.plan_mode != "learned" or not model.plugin.enabled:
        raise ValueError("v2 task objectives require enabled learned UOT")
    deficit = reference_deficit(state)
    terms["reference_deficit"] = deficit.mean()
    readout_dtype = next(model.parameters()).dtype
    task_inputs = {key: value.to(readout_dtype) if torch.is_tensor(value) and value.is_floating_point() else value
                   for key, value in native_inputs.items()}
    with _preserve_forward_state(model) as original_flags, torch.autocast(device_type=state.plans.device.type, enabled=False):
        if rw > 0:
            detached_plan = state.plans.detach()
            mass = detached_plan.sum((-2, -1))
            eligible = int((mass > config.min_plan_mass).sum())
            diagnostics["relation_eligible_plans"] = eligible
            if eligible:
                model.eval()
                # Only these live pair-cost networks receive relation gradients.
                cost_dtype = next(model.plugin.core.stage_pair_cost.parameters()).dtype
                costs = model.plugin.core.costs_and_marginals(state.wsi_slots.detach().to(cost_dtype), state.omics_slots.detach().to(cost_dtype))[0]
                projected = fixed_realized_marginal_plan(
                    costs, detached_plan.sum(-1), detached_plan.sum(-2), epsilon=model.plugin.core.epsilon(epoch),
                    iterations=config.projection_iters, tolerance=config.projection_tolerance, min_mass=config.min_plan_mass)
                diagnostics["projection_plan_max_abs_delta"] = float((projected.detach()-detached_plan).abs().max())
                model.plugin._task_encoded_inputs = tuple(value.detach().to(readout_dtype) for value in inputs)
                kwargs = {**task_inputs, "cur_epoch": epoch, "plugin_compute_aux": False, "plugin_enabled": True}
                model.plugin._task_state_override = _controlled_state(model.plugin.core, state, projected)
                factual = functional_call(model, _frozen_weights(model), (), kwargs)
                factual_nll = _criterion(survival_loss, _prediction(factual, backbone_name))
                with torch.no_grad():
                    model.plugin._task_state_override = _controlled_state(model.plugin.core, state, realized_independent_plan(detached_plan))
                    independent = functional_call(model, _frozen_weights(model), (), kwargs)
                    independent_nll = _criterion(survival_loss, _prediction(independent, backbone_name))
                relation = (factual_nll-independent_nll.detach()-config.relation_tolerance).clamp_min(0.)
                terms.update(relation_raw=relation, relation_weighted=rw*relation,
                             relation_factual_nll=factual_nll.detach(), relation_independent_nll=independent_nll.detach())
            else:
                diagnostics["relation_skipped"] = "no_plan_above_numerical_mass_threshold"
        # Remove controlled readout before real native-path supervision.
        model.plugin._task_state_override = None
        # Restore every original mode, including mixed per-module settings.
        # The context restores them again on success and any callback failure.
        for module, training in original_flags:
            module.training = training
        if nw > 0:
            kwargs = {**task_inputs, "cur_epoch": epoch, "plugin_compute_aux": False, "plugin_enabled": False}
            native = model(**kwargs)
            native_nll = _criterion(survival_loss, _prediction(native, backbone_name))
            native_term = deficit.mean() * native_nll
            terms.update(native_raw=native_term, native_weighted=nw*native_term, native_nll=native_nll.detach())
    total = terms["relation_weighted"] + terms["native_weighted"]
    if not bool(torch.isfinite(total)):
        raise ValueError("nonfinite v2 task loss")
    return TransportV2TaskLossOutput(total, terms, diagnostics)
