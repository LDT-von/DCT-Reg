"""Versioned partial-correspondence transport configuration (not a v1 recipe)."""
from dataclasses import dataclass, fields
import math

from ..transport.config import TransportPluginConfig


@dataclass(frozen=True)
class TransportPluginV2Config(TransportPluginConfig):
    transport_mode: str = "uot"
    cost_mode: str = "bounded"
    mass_aware: bool = True
    tau_wsi: float = .5
    tau_omics: float = .5
    cost_scale: float = 1.
    euclidean_scale: float | None = None
    uot_iters: int = 200
    uot_tolerance: float = 1e-7

    def __post_init__(self):
        super().__post_init__()
        if self.transport_mode not in {"balanced", "uot"}:
            raise ValueError("transport_mode must be balanced or uot")
        if self.cost_mode not in {"bounded", "legacy"}:
            raise ValueError("cost_mode must be bounded or legacy")
        if self.transport_mode == "uot" and self.cost_mode != "bounded":
            raise ValueError("UOT requires bounded absolute costs; legacy normalization removes offsets")
        if self.plan_mode == "uniform":
            raise ValueError("v2 uses learned or actual-marginal independent plans, not uniform")
        if not isinstance(self.mass_aware, bool):
            raise TypeError("mass_aware must be bool")
        for name in ("tau_wsi", "tau_omics", "cost_scale", "uot_tolerance"):
            value = getattr(self, name)
            if isinstance(value, bool) or not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        if isinstance(self.uot_iters, bool) or not isinstance(self.uot_iters, int) or self.uot_iters < 1:
            raise ValueError("uot_iters must be a positive integer")
        scale = math.sqrt(self.dim) if self.euclidean_scale is None else self.euclidean_scale
        if isinstance(scale, bool) or not math.isfinite(scale) or scale <= 0:
            raise ValueError("euclidean_scale must be finite and positive")
        object.__setattr__(self, "euclidean_scale", float(scale))

    def legacy_configuration(self):
        """Only shared structural fields, for identical native/v1 initialization."""
        return {field.name: getattr(self, field.name) for field in fields(TransportPluginConfig)}
