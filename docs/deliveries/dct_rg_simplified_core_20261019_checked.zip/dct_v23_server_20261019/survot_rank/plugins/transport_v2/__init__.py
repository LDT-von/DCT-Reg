"""Isolated v2 API. Importing it does not alter v1 or the DCT method registry."""
from .config import TransportPluginV2Config
from .core import TransportCoreV2, TransportStateV2, realized_independent_plan
from .plugin import DCTTransportPluginV2


def __getattr__(name):
    # Pure mechanism consumers must not load the historical task-loss recipe.
    # Preserve all previous public imports for callers that explicitly use it.
    if name == "build_native_adapter_v2":
        from .native import build_native_adapter_v2
        return build_native_adapter_v2
    if name in {"TransportV2TaskLossConfig", "TransportV2TaskLossOutput",
                "compute_transport_v2_task_losses", "fixed_realized_marginal_plan",
                "reference_deficit"}:
        from . import losses
        return getattr(losses, name)
    raise AttributeError(name)

__all__ = ["TransportPluginV2Config", "TransportCoreV2", "TransportStateV2",
           "realized_independent_plan", "DCTTransportPluginV2", "build_native_adapter_v2",
           "TransportV2TaskLossConfig", "TransportV2TaskLossOutput",
           "compute_transport_v2_task_losses", "fixed_realized_marginal_plan", "reference_deficit"]
