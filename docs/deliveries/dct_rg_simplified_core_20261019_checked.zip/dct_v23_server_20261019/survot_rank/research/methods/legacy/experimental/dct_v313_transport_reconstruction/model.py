"""DCT v3.13: transport-aware pathway reconstruction.

Reconstruction decoder sharing does not change the factual prediction path.
During training, v3.13 uses these auxiliary reconstruction objectives:

* omics semantic slots reconstruct the encoded pathway tokens;
* WSI slots are transported into omics slot coordinates by the factual,
  stage-wise, multi-geometry Sinkhorn plans and reconstruct the same targets.
* when enabled, WSI slots reconstruct valid projected patch features.

The repaired recipe can use independent self/cross pathway decoders. These
heads affect training gradients but are never called for survival inference.

The reconstruction target is stop-gradient.  The event gate used to combine
stages is detached so the auxiliary objective cannot repurpose the survival
gate, while gradients still flow through the factual transport plans, shared
semantic slots, and both modality encoders.
"""

from __future__ import annotations

import json
import copy
import math
import os
import sys
import time
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

from survot_rank.research.methods.legacy.experimental.dct_v313_transport_reconstruction.wsi_reconstruction import WSISlotReconstructionDecoder
from survot_rank.research.methods.legacy.experimental.dct_v313_transport_reconstruction.diversity import repaired_slot_diversity_loss

from survot_rank.research.methods.legacy.experimental.dct_v311_slot_interpretable.model import (
    DCTV311SlotInterpretable,
)


_DEBUG_LOG_PATH = Path(os.environ.get(
    "DCT_DEBUG_LOG",
    "/data1/DCT-Reg/.cursor/debug-486347.log",
))


def _debug_log(hypothesis_id: str, location: str, message: str, data: dict) -> None:
    """Append a single NDJSON line to the debug log (session 486347)."""
    try:
        payload = {
            "id": f"log_{int(time.time()*1000)}_{os.getpid()}",
            "timestamp": int(time.time() * 1000),
            "location": location,
            "message": message,
            "data": data,
            "runId": os.environ.get("DCT_DEBUG_RUN_ID", "ablation"),
            "hypothesisId": hypothesis_id,
        }
        _DEBUG_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with _DEBUG_LOG_PATH.open("a") as f:
            f.write(json.dumps(payload) + "\n")
    except Exception as e:  # pragma: no cover — never break training
        try:
            sys.stderr.write(f"[debug-log] {e}\n")
        except Exception:
            pass


class OmicsTokenReconstructionDecoder(nn.Module):
    """Decode a fixed set of pathway tokens from semantic slot memory."""

    def __init__(self, dim: int, num_pathways: int, num_heads: int) -> None:
        super().__init__()
        self.pathway_queries = nn.Parameter(torch.empty(1, num_pathways, dim))
        nn.init.trunc_normal_(self.pathway_queries, std=0.02)
        self.query_norm = nn.LayerNorm(dim)
        self.memory_norm = nn.LayerNorm(dim)
        self.cross_attention = nn.MultiheadAttention(
            embed_dim=dim,
            num_heads=num_heads,
            batch_first=True,
        )
        self.output_norm = nn.LayerNorm(dim)
        self.output_mlp = nn.Sequential(
            nn.Linear(dim, dim * 2),
            nn.GELU(),
            nn.Linear(dim * 2, dim),
        )

    def forward(self, memory: torch.Tensor) -> torch.Tensor:
        if memory.ndim != 3:
            raise ValueError(f"slot memory must be [B, K, D], got {tuple(memory.shape)}")
        queries = self.pathway_queries.expand(memory.size(0), -1, -1)
        decoded, _ = self.cross_attention(
            self.query_norm(queries),
            self.memory_norm(memory),
            self.memory_norm(memory),
            need_weights=False,
        )
        decoded = queries + decoded
        return decoded + self.output_mlp(self.output_norm(decoded))


class DCTV313TransportReconstruction(DCTV311SlotInterpretable):
    """DCT v3.13 with omics self- and transport-aware cross-reconstruction."""

    RECONSTRUCTION_WEIGHT = 0.10
    RECONSTRUCTION_SELF_FRACTION = 0.50
    RECONSTRUCTION_CROSS_FRACTION = 0.50
    RECONSTRUCTION_RAMP_START = 2
    RECONSTRUCTION_RAMP_EPOCHS = 5

    FROZEN_ARGUMENTS = dict(DCTV311SlotInterpretable.FROZEN_ARGUMENTS)
    FROZEN_ARGUMENTS.update(
        {
            "dct_v313_lambda_reconstruction": RECONSTRUCTION_WEIGHT,
            "dct_v313_reconstruction_self_fraction": RECONSTRUCTION_SELF_FRACTION,
            "dct_v313_reconstruction_cross_fraction": RECONSTRUCTION_CROSS_FRACTION,
            "dct_v313_reconstruction_ramp_start": RECONSTRUCTION_RAMP_START,
            "dct_v313_reconstruction_ramp_epochs": RECONSTRUCTION_RAMP_EPOCHS,
        }
    )

    def __init__(self, args, omic_input_dim=None, omic_names=None, pathway_names=None):
        self._v313_revision = str(getattr(args, "dct_v313_revision", "legacy")).lower()
        self._v313_explicit_config_keys = set(getattr(args, "_dct_user_overrides", ()))
        if self._v313_revision not in {"legacy", "repaired"}:
            raise ValueError("dct_v313_revision must be legacy or repaired")
        self._omics_decoder_mode = str(getattr(args, "dct_v313_omics_decoder_mode", "shared")).lower()
        if self._omics_decoder_mode not in {"shared", "separate"}:
            raise ValueError("dct_v313_omics_decoder_mode must be shared or separate")
        if self._omics_decoder_mode == "separate" and self._v313_revision != "repaired":
            raise ValueError("separate pathway decoders require dct_v313_revision=repaired")
        if str(getattr(args, "rna_format", "Pathways")) != "Pathways":
            raise ValueError(
                "DCT v3.13 reconstructs pathway tokens and requires rna_format='Pathways'"
            )
        # Respect CLI `--set` overrides: FROZEN_ARGUMENTS only stamp keys the
        # caller did not already supply (ablation studies).
        v313_frozen = {
            name: value
            for name, value in self.FROZEN_ARGUMENTS.items()
            if name not in getattr(args, "_dct_user_overrides", set())
        }
        if self._v313_revision == "repaired" and "dct_v311_lambda_slot_diversity" in v313_frozen:
            # The repaired recipe agrees with its declared 0.10 default.
            # Explicit configuration values still take precedence.
            v313_frozen["dct_v311_lambda_slot_diversity"] = self.SLOT_DIVERSITY_WEIGHT
        for name, value in v313_frozen.items():
            setattr(args, name, value)
        # Ablation hooks: allow callers to override reconstruction knobs
        # via args (FROZEN_ARGUMENTS already populated, but ablation flags
        # like --dct_v313_disable_self_reconstruction=true force zero weights).
        def _as_bool(v):
            if isinstance(v, bool):
                return v
            return str(v).lower() in ("1", "true", "yes", "y", "on")

        self._ablation_disable_self = _as_bool(
            getattr(args, "dct_v313_disable_self_reconstruction", False)
        )
        self._ablation_disable_cross = _as_bool(
            getattr(args, "dct_v313_disable_cross_reconstruction", False)
        )
        self._ablation_lambda_scale = float(
            getattr(args, "dct_v313_lambda_reconstruction_scale", 1.0)
        )
        # §3.1 #3: cross-reconstruction mode.
        #
        # ``transport`` (default): pass OT-transported WSI slots to the
        # cross decoder.  ``direct``: pass the un-transported WSI slots
        # directly, isolating the OT contribution to cross reconstruction.
        cross_mode = str(getattr(args, "dct_v313_cross_mode", "transport")).lower()
        if cross_mode not in ("transport", "direct"):
            raise ValueError(
                "dct_v313_cross_mode must be 'transport' or 'direct', got "
                f"{cross_mode!r}"
            )
        self._cross_mode = cross_mode
        # §3.1 #4: OT plan mode.
        #
        # ``learned`` (default): use the Sinkhorn-projected OT plans from
        # the evidence-cost geometry.  ``independent``: replace the plan
        # with T = a bᵀ (outer product of marginals) in every consumer.
        plan_mode = str(getattr(args, "dct_v313_plan_mode", "learned")).lower()
        if plan_mode not in ("learned", "independent"):
            raise ValueError(
                "dct_v313_plan_mode must be 'learned' or 'independent', got "
                f"{plan_mode!r}"
            )
        self._plan_mode = plan_mode
        weighting_mode = str(getattr(args, "dct_v313_recon_weighting", "legacy")).lower()
        if weighting_mode not in ("legacy", "per_branch"):
            raise ValueError(
                "dct_v313_recon_weighting must be 'legacy' or 'per_branch', got "
                f"{weighting_mode!r}"
            )
        self._recon_weighting_mode = weighting_mode
        if self._v313_revision == "repaired" and weighting_mode != "per_branch":
            raise ValueError("repaired v3.13 requires dct_v313_recon_weighting=per_branch")
        self._wsi_reconstruction_requested = float(
            getattr(args, "dct_v313_lambda_wsi_reconstruction", 0.0)
        )
        self._wsi_reconstruction_budget = str(
            getattr(args, "dct_v313_wsi_reconstruction_budget", "additive")
        ).lower()
        self._wsi_reconstruction_chunk_size = int(
            getattr(args, "dct_v313_wsi_reconstruction_chunk_size", 256)
        )
        if not math.isfinite(self._wsi_reconstruction_requested) or self._wsi_reconstruction_requested < 0:
            raise ValueError("dct_v313_lambda_wsi_reconstruction must be finite and nonnegative")
        if self._wsi_reconstruction_budget not in ("additive", "fixed_total"):
            raise ValueError("dct_v313_wsi_reconstruction_budget must be additive or fixed_total")
        if self._wsi_reconstruction_chunk_size <= 0:
            raise ValueError("dct_v313_wsi_reconstruction_chunk_size must be positive")
        if self._wsi_reconstruction_requested > 0 and weighting_mode != "per_branch":
            raise ValueError("WSI reconstruction requires dct_v313_recon_weighting=per_branch")
        if self._v313_revision == "repaired":
            # Parent constructors must not restore the inherited 0.02 value.
            args._dct_user_overrides = set(getattr(args, "_dct_user_overrides", ())) | {
                "dct_v311_lambda_slot_diversity"
            }
        super().__init__(args, omic_input_dim, omic_names, pathway_names)

        dim = int(self.wsi_projection_dim)
        if self._v313_revision == "repaired":
            def resolved(name, default):
                value = getattr(args, name, default)
                value = float(default if value is None else value)
                if not math.isfinite(value) or value < 0:
                    raise ValueError(name + " must be finite and nonnegative")
                return value
            recon_weight = resolved("dct_v313_lambda_reconstruction", self.RECONSTRUCTION_WEIGHT)
            self_fraction = resolved("dct_v313_reconstruction_self_fraction", self.RECONSTRUCTION_SELF_FRACTION)
            cross_fraction = resolved("dct_v313_reconstruction_cross_fraction", self.RECONSTRUCTION_CROSS_FRACTION)
            if not math.isclose(self_fraction + cross_fraction, 1.0):
                raise ValueError("repaired reconstruction self/cross fractions must sum to one")
            ramp_start = resolved("dct_v313_reconstruction_ramp_start", self.RECONSTRUCTION_RAMP_START)
            ramp_epochs = resolved("dct_v313_reconstruction_ramp_epochs", self.RECONSTRUCTION_RAMP_EPOCHS)
            if not ramp_start.is_integer() or not ramp_epochs.is_integer():
                raise ValueError("reconstruction ramp start/epochs must be nonnegative integers")
        else:
            recon_weight = self.RECONSTRUCTION_WEIGHT
            self_fraction = self.RECONSTRUCTION_SELF_FRACTION
            cross_fraction = self.RECONSTRUCTION_CROSS_FRACTION
            ramp_start = self.RECONSTRUCTION_RAMP_START
            ramp_epochs = self.RECONSTRUCTION_RAMP_EPOCHS
        # ------------------------------------------------------------------
        # Effective per-branch reconstruction coefficients.
        #
        # The original two coefficients are computed first; optional WSI
        # coefficients/budget adjustment are applied below.
        # The same pair is consumed by `reconstruction_losses` and
        # `forward`, so the value the combiner multiplies with is exactly
        # what the audit log reports.  ``dct_v313_lambda_reconstruction_effective``
        # holds the SUM of the active branches — i.e. the constant that the legacy code
        # used to renormalise to (no double-down).
        #
        #   - legacy     (commit 93d8314): ``coef_i = effective_weight × fraction_i``.
        #     When one branch is disabled the legacy renormalisation keeps
        #     the SUM constant (== RECONSTRUCTION_WEIGHT), so the surviving
        #     per-branch coefficient is the half-constant 0.025 (the historic
        #     "double-down" weakness — compensated in some ablation runs by
        #     scale=2).
        #   - per_branch (new v3.13 paper recipe): ``coef_i = WEIGHT × fraction_i``
        #     independently of the disable flags.  Disabling self zeros only
        #     the self term; cross keeps its full constant 0.05.  Disable
        #     cross → only self survives at 0.05.
        #   - scale=1 is mandatory in per_branch mode; the historic scale=2
        #     compensation from the legacy recipe MUST NOT be carried over.
        # ------------------------------------------------------------------
        frac_sum = max(
            self.RECONSTRUCTION_SELF_FRACTION + self.RECONSTRUCTION_CROSS_FRACTION, 1e-8
        )
        if self._recon_weighting_mode == "legacy":
            if self._ablation_disable_self and self._ablation_disable_cross:
                legacy_renormalised_weight = 0.0
            elif self._ablation_disable_self:
                legacy_renormalised_weight = (
                    self.RECONSTRUCTION_WEIGHT
                    * self._ablation_lambda_scale
                    * self.RECONSTRUCTION_CROSS_FRACTION
                    / frac_sum
                )
            elif self._ablation_disable_cross:
                legacy_renormalised_weight = (
                    self.RECONSTRUCTION_WEIGHT
                    * self._ablation_lambda_scale
                    * self.RECONSTRUCTION_SELF_FRACTION
                    / frac_sum
                )
            else:
                legacy_renormalised_weight = (
                    self.RECONSTRUCTION_WEIGHT * self._ablation_lambda_scale
                )
            self_branch_coef = (
                0.0
                if self._ablation_disable_self
                else legacy_renormalised_weight * self.RECONSTRUCTION_SELF_FRACTION
            )
            cross_branch_coef = (
                0.0
                if self._ablation_disable_cross
                else legacy_renormalised_weight * self.RECONSTRUCTION_CROSS_FRACTION
            )
        else:  # per_branch
            if self._ablation_lambda_scale != 1.0:
                raise ValueError(
                    "dct_v313_recon_weighting='per_branch' forbids "
                    "dct_v313_lambda_reconstruction_scale != 1.0 "
                    "(got {scale}).  The legacy scale=2 compensation must NOT be "
                    "carried into the new recipe.".format(
                        scale=self._ablation_lambda_scale
                    )
                )
            self_branch_coef = (
                0.0
                if self._ablation_disable_self
                else recon_weight * self_fraction
            )
            cross_branch_coef = (
                0.0
                if self._ablation_disable_cross
                else recon_weight * cross_fraction
            )

        wsi_branch_coef = self._wsi_reconstruction_requested
        if wsi_branch_coef > 0 and self._wsi_reconstruction_budget == "fixed_total":
            original_budget = self_branch_coef + cross_branch_coef
            if original_budget <= 0:
                raise ValueError("fixed_total WSI reconstruction requires an active omics reconstruction branch")
            factor = original_budget / (original_budget + wsi_branch_coef)
            self_branch_coef *= factor
            cross_branch_coef *= factor
            wsi_branch_coef *= factor
        self.dct_v313_reconstruction_wsi_coef = wsi_branch_coef
        self.dct_v313_reconstruction_self_coef = self_branch_coef
        self.dct_v313_reconstruction_cross_coef = cross_branch_coef
        # ``dct_v313_lambda_reconstruction_effective`` reports the SUM of
        # all active per-branch coefficients — i.e. the maximum coefficient that the
        # combiner can apply to the loss before the ramp multiplier.  This
        # replaces the legacy "renormalised weight" semantics and makes the
        # audit field directly comparable to ``effective_recon_coefficients()``.
        self.dct_v313_lambda_reconstruction_effective = (
            self_branch_coef + cross_branch_coef + wsi_branch_coef
        )
        self.dct_v313_reconstruction_self_fraction = (
            0.0 if self._ablation_disable_self else self_fraction
        )
        self.dct_v313_reconstruction_cross_fraction = (
            0.0 if self._ablation_disable_cross else cross_fraction
        )
        self.dct_v313_reconstruction_ramp_start = int(ramp_start)
        self.dct_v313_reconstruction_ramp_epochs = int(ramp_epochs)
        heads = self._compatible_num_heads(dim, int(getattr(args, "otehv2_heads", 4)))
        self.pathway_reconstruction_decoder = OmicsTokenReconstructionDecoder(
            dim=dim,
            num_pathways=int(self.num_pathways),
            num_heads=heads,
        )
        self.cross_pathway_reconstruction_decoder = None
        if self._omics_decoder_mode == "separate":
            # Equal starting weights make the sharing comparison fair. A deep
            # copy has independent parameter storage and consumes no RNG, so
            # all prediction and WSI decoder initialization remains identical.
            self.cross_pathway_reconstruction_decoder = copy.deepcopy(
                self.pathway_reconstruction_decoder
            )
        # Disabled means no module, no new parameters, and no extra RNG draws.
        # Instantiate after existing modules to preserve shared initial weights.
        self.wsi_reconstruction_decoder = None
        if self.dct_v313_reconstruction_wsi_coef > 0:
            # Keep the caller's CPU RNG continuation identical across arms.
            with torch.random.fork_rng(devices=[]):
                self.wsi_reconstruction_decoder = WSISlotReconstructionDecoder(
                    dim, heads, self._wsi_reconstruction_chunk_size,
                )
        self._last_reconstruction_self = 0.0
        self._last_reconstruction_cross = 0.0
        self._last_reconstruction_total = 0.0
        self.last_diversity_diagnostics = {}
        self._last_reconstruction_ramp = 0.0
        # Honour ablation flags for per-slot NLL and diversity too (added Sep 29 2026
        # after discovering v3.13 hard-coded PER_SLOT_NLL_WEIGHT in aux_loss, which
        # made --set dct_v311_lambda_slot_nll=0 silently ignored).
        self.dct_v313_lambda_slot_nll_effective = float(
            getattr(args, "dct_v311_lambda_slot_nll", self.PER_SLOT_NLL_WEIGHT)
        )
        self.dct_v313_lambda_slot_diversity_effective = float(
            getattr(args, "dct_v311_lambda_slot_diversity", self.SLOT_DIVERSITY_WEIGHT)
        )
        # #region agent log — H1: verify effective weights match args
        _debug_log(
            hypothesis_id="H1",
            location="dct_v313/model.py:init",
            message="effective weights at init",
            data={
                "args_dct_v311_lambda_slot_nll": float(getattr(args, "dct_v311_lambda_slot_nll", -1.0)),
                "args_dct_v311_lambda_slot_diversity": float(getattr(args, "dct_v311_lambda_slot_diversity", -1.0)),
                "args_dct_lambda_ipcw_rank": float(getattr(args, "dct_lambda_ipcw_rank", -1.0)),
                "args_dct_v313_disable_self_reconstruction": getattr(args, "dct_v313_disable_self_reconstruction", None),
                "args_dct_v313_disable_cross_reconstruction": getattr(args, "dct_v313_disable_cross_reconstruction", None),
                "args_dct_v313_recon_weighting": getattr(args, "dct_v313_recon_weighting", None),
                "self_dct_v313_lambda_slot_nll_effective": self.dct_v313_lambda_slot_nll_effective,
                "self_dct_v313_lambda_slot_diversity_effective": self.dct_v313_lambda_slot_diversity_effective,
                "self_dct_v313_lambda_reconstruction_effective": self.dct_v313_lambda_reconstruction_effective,
                "self_dct_v313_reconstruction_self_coef": float(self.dct_v313_reconstruction_self_coef),
                "self_dct_v313_reconstruction_cross_coef": float(self.dct_v313_reconstruction_cross_coef),
                "self_dct_v313_recon_weighting_mode": self._recon_weighting_mode,
                "PER_SLOT_NLL_WEIGHT_class_const": self.PER_SLOT_NLL_WEIGHT,
                "SLOT_DIVERSITY_WEIGHT_class_const": self.SLOT_DIVERSITY_WEIGHT,
                "class_id": id(self.__class__),
            },
        )
        # #endregion agent log

    @staticmethod
    def _compatible_num_heads(dim: int, preferred: int) -> int:
        heads = max(1, min(int(preferred), int(dim)))
        while dim % heads != 0:
            heads -= 1
        return heads

    @classmethod
    def objective_weights(cls) -> dict[str, float]:
        """Return the abstract recipe weight dict (class-constant only).

        §3.1 #1: in ``per_branch`` mode the reconstruction loss is decomposed
        into per-branch keys (``self``, ``cross``) and the aggregated
        ``reconstruction`` key is *omitted*.  In ``legacy`` mode the original
        aggregated key is returned for backward compatibility.  Use the
        instance-level ``objective_weights()`` for effective post-init values
        (FROZEN override accounting).
        """
        weights = {
            "nll": cls.NLL_WEIGHT,
            "ipcw_rank": cls.IPCW_RANK_WEIGHT,
            "per_slot_nll": cls.PER_SLOT_NLL_WEIGHT,
            "slot_diversity": cls.SLOT_DIVERSITY_WEIGHT,
            "weighting_mode": "per_branch",
        }
        weights["reconstruction_self"] = (
            cls.RECONSTRUCTION_WEIGHT * cls.RECONSTRUCTION_SELF_FRACTION
        )
        weights["reconstruction_cross"] = (
            cls.RECONSTRUCTION_WEIGHT * cls.RECONSTRUCTION_CROSS_FRACTION
        )
        return weights

    def objective_weights_effective(self) -> dict[str, float]:
        """Return the *effective* objective weights actually applied at
        forward time (after FROZEN overrides and ablation flags).

        Companion to :meth:`objective_weights`.  Use this when you need the
        exact coefficients that multiplied each loss term — for audit logs,
        weight summaries, and downstream consumers that care about the
        post-construction effective weights rather than the abstract
        recipe.
        """
        weights = {
            "nll": self.NLL_WEIGHT,
            "ipcw_rank": self.dct_lambda_ipcw_rank,
            "per_slot_nll": self.dct_v313_lambda_slot_nll_effective,
            "slot_diversity": self.dct_v313_lambda_slot_diversity_effective,
            "weighting_mode": self._recon_weighting_mode,
        }
        if self._recon_weighting_mode == "per_branch":
            weights["reconstruction_self"] = float(self.dct_v313_reconstruction_self_coef)
            weights["reconstruction_cross"] = float(self.dct_v313_reconstruction_cross_coef)
        else:
            weights["reconstruction"] = self.RECONSTRUCTION_WEIGHT
            weights["reconstruction_self"] = (
                self.RECONSTRUCTION_WEIGHT * self.RECONSTRUCTION_SELF_FRACTION
            )
            weights["reconstruction_cross"] = (
                self.RECONSTRUCTION_WEIGHT * self.RECONSTRUCTION_CROSS_FRACTION
            )
        if self.dct_v313_reconstruction_wsi_coef > 0:
            weights["reconstruction_wsi"] = float(self.dct_v313_reconstruction_wsi_coef)
        return weights

    # The v3.14 schema emitter historically invoked
    # ``self.objective_weights()`` on a live instance.  With the dual-API
    # change, ``objective_weights`` is the abstract recipe (classmethod);
    # ``objective_weights_effective`` is the post-FROZEN actual values.
    # Callers that need the abstract recipe on an instance should use
    # ``type(self).objective_weights()`` (or equivalently, call the
    # classmethod directly).

    def effective_recon_coefficients(self) -> dict[str, float]:
        """Return the *effective* per-branch coefficients actually used by
        `reconstruction_losses` after weighting mode and ablation flags are
        applied.  Always reflects what the forward pass multiplies the loss
        terms by, so it can be cross-referenced with the audit log without
        guessing the mode.
        """
        coefficients = {
            "weighting_mode": self._recon_weighting_mode,
            "self": float(self.dct_v313_reconstruction_self_coef),
            "cross": float(self.dct_v313_reconstruction_cross_coef),
            "total": float(self.dct_v313_lambda_reconstruction_effective),
            "disable_self": bool(self._ablation_disable_self),
            "disable_cross": bool(self._ablation_disable_cross),
            "lambda_scale": float(self._ablation_lambda_scale),
            "cross_mode": self._cross_mode,
            "plan_mode": self._plan_mode,
        }
        if self._v313_revision == "repaired":
            coefficients.update(
                revision="repaired",
                omics_decoder_mode=self._omics_decoder_mode,
                wsi=float(self.dct_v313_reconstruction_wsi_coef),
                cross_conditioning="paired_wsi_and_omics" if self._cross_mode == "transport" else "wsi_slots",
            )
        if self.dct_v313_reconstruction_wsi_coef > 0:
            coefficients.update(
                wsi=float(self.dct_v313_reconstruction_wsi_coef),
                wsi_requested=self._wsi_reconstruction_requested,
                wsi_budget=self._wsi_reconstruction_budget,
                wsi_chunk_size=self._wsi_reconstruction_chunk_size,
                wsi_target="detached_projected_patch_features",
                wsi_query="frozen_random_projection_of_detached_target",
                wsi_loss="cosine_patient_mean",
            )
        return coefficients

    def reconstruction_decoder_layout(self):
        """Registered head layout; a zero-weight branch can retain its head."""
        return {
            "omics_decoder_mode": self._omics_decoder_mode,
            "self": "pathway_reconstruction_decoder",
            "cross": "cross_pathway_reconstruction_decoder" if self._omics_decoder_mode == "separate" else "pathway_reconstruction_decoder",
            "wsi": "wsi_reconstruction_decoder" if self.wsi_reconstruction_decoder is not None else None,
            "decoder_count": 1 + int(self.cross_pathway_reconstruction_decoder is not None) + int(self.wsi_reconstruction_decoder is not None),
            "cross_initialization": "independent_copy_of_self" if self._omics_decoder_mode == "separate" else "shared_parameters",
            "used_in_survival_inference": False,
            "auxiliary_gradients_update_backbone": True,
        }

    def implementation_audit(self):
        """Describe the active computation, rather than configuration comments.

        Reconstruction targets are encoded features. Neither low reconstruction
        error nor separated slot states establishes biological slot identities.
        """
        return {
            "revision": self._v313_revision,
            "objective_weights": self.objective_weights_effective(),
            "reconstruction": self.effective_recon_coefficients(),
            "reconstruction_decoders": self.reconstruction_decoder_layout(),
            "reconstruction_ramp": {
                "start": self.dct_v313_reconstruction_ramp_start,
                "epochs": self.dct_v313_reconstruction_ramp_epochs,
            },
            "input_padding_mask": self._v313_revision == "repaired",
            "diversity_reduction": "mean_pair_hinge_per_patient" if self._v313_revision == "repaired" else "legacy_mean_distance_hinge",
            "exact_collapse_gradient_guarantee": False,
            "biological_slot_identity_proven": False,
            "missing_omics_recovery_proven": False,
        }

    def _wsi_valid_patch_mask(self, kwargs):
        """Use explicit patch ownership when supplied, otherwise infer zero padding."""
        raw = kwargs["x_wsi"]
        if raw.ndim != 3:
            raise ValueError("x_wsi must have shape [B, N, D]")
        explicit = kwargs.get("wsi_patch_mask")
        if explicit is None:
            valid = raw.detach().ne(0).any(dim=-1)
        else:
            valid = torch.as_tensor(explicit, device=raw.device)
            if valid.dtype != torch.bool or valid.shape != raw.shape[:2]:
                raise ValueError("wsi_patch_mask must be boolean [B, N], True=valid")
        def patient_flag(name, default):
            value = kwargs.get(name, default)
            if value is None:
                value = default
            flag = torch.as_tensor(value, device=raw.device, dtype=torch.bool)
            if flag.numel() == 1:
                return flag.reshape(1).expand(raw.size(0))
            if flag.shape != (raw.size(0),):
                raise ValueError(name + " must be a scalar or boolean [B]")
            return flag
        available = patient_flag("wsi_available", True)
        missing = patient_flag("wsi_missing", False)
        return valid & (available & ~missing).unsqueeze(-1)

    def _encode_transport_slots(self, x_wsi_proj, x_omics, kwargs):
        if self._v313_revision == "legacy":
            return super()._encode_transport_slots(x_wsi_proj, x_omics, kwargs)
        valid = kwargs.get("_v313_valid_wsi_patches")
        if valid is None:
            valid = self._wsi_valid_patch_mask(kwargs)
        local_wsi = self.slot_attention_wsi(x_wsi_proj, token_mask=valid)
        local_omic = self.slot_attention_omic(x_omics)
        sw, aw = self._semantic_slots(local_wsi, self.shared_wsi_prototypes)
        so, ao = self._semantic_slots(local_omic, self.shared_omic_prototypes)
        return sw, so, aw, ao

    def slot_diversity_loss(self, slots_wsi, slots_omic):
        if self._v313_revision == "legacy":
            return super().slot_diversity_loss(slots_wsi, slots_omic)
        def configured(name, default):
            value = getattr(self.args, name, None)
            return default if value is None else float(value)
        loss, diagnostics = repaired_slot_diversity_loss(
            slots_wsi, slots_omic,
            torch.sigmoid(self.per_slot_hazard_wsi(slots_wsi)),
            torch.sigmoid(self.per_slot_hazard_omic(slots_omic)),
            variance_min=configured("dct_v311_variance_min", self.VARIANCE_MIN),
            variance_max=configured("dct_v311_variance_max", self.VARIANCE_MAX),
            target_pair_dist=configured("dct_v311_target_pair_dist", 1.0),
            pair_weight=configured("dct_v311_lambda_pair_dist", self.PAIR_DIST_WEIGHT),
        )
        self.last_diversity_diagnostics = diagnostics
        for modality in ("wsi", "omic"):
            stats = diagnostics[modality]
            setattr(self, "_last_slot_variance_" + modality, stats["hazard_variance"])
            setattr(self, "_last_slot_pair_dist_" + modality, stats["mean_pair_distance_sq"] ** 0.5)
        self._last_slot_variance = 0.5 * (
            diagnostics["wsi"]["hazard_variance"] + diagnostics["omic"]["hazard_variance"]
        )
        self._last_slot_diversity = float(loss.detach())
        return loss

    @classmethod
    def key_contributions(cls) -> list[str]:
        return [
            "Paired cross-modal pathway reconstruction through factual Sinkhorn plans",
            "Omics semantic-slot self-reconstruction at pathway-token resolution",
            "Per-slot survival supervision with modality-specific diversity constraints",
            "IPCW-aware patient-risk ranking",
        ]

    # DCT-Reg main did not receive commit 982a090 from the v3.11 repository.
    # Override the historical method locally so v3.13 uses the fixed cumulative
    # discrete-time likelihood without rewriting the archived v3.11 baseline.
    def _nll_surv_per_slot(self, hazard, y_onehot, event_mask, censor_mask, ipcw):
        eps = 1e-7
        hazard = hazard.clamp(min=eps, max=1.0 - eps)
        log_hazard = hazard.log()
        log_survival = torch.log1p(-hazard).cumsum(dim=-1)
        log_survival_padded = torch.cat(
            [torch.zeros_like(log_survival[..., :1]), log_survival], dim=-1
        )

        y_index = y_onehot.argmax(dim=-1, keepdim=True)
        y_index = y_index.unsqueeze(1).expand(-1, hazard.size(1), -1)
        survival_before = torch.gather(
            log_survival_padded, dim=-1, index=y_index
        ).squeeze(-1)
        hazard_at_event = torch.gather(log_hazard, dim=-1, index=y_index).squeeze(-1)
        survival_at_censor = torch.gather(
            log_survival_padded,
            dim=-1,
            index=(y_index + 1).clamp(max=log_survival_padded.size(-1) - 1),
        ).squeeze(-1)

        event_nll = -(survival_before + hazard_at_event) * event_mask
        censor_nll = -survival_at_censor * censor_mask
        return (event_nll + censor_nll) * ipcw

    def _reconstruction_ramp(self, epoch: int) -> float:
        start = int(self.dct_v313_reconstruction_ramp_start)
        duration = int(self.dct_v313_reconstruction_ramp_epochs)
        if duration <= 0:
            return 1.0
        return min(1.0, max(0.0, (float(epoch) - float(start)) / float(duration)))

    @staticmethod
    def _batch_bool_mask(value, *, batch: int, device, default: bool) -> torch.Tensor:
        if value is None:
            return torch.full((batch,), default, dtype=torch.bool, device=device)
        if torch.is_tensor(value):
            mask = value.to(device=device, dtype=torch.bool).reshape(-1)
            if mask.numel() == 1:
                return mask.expand(batch)
            if mask.numel() != batch:
                raise ValueError(
                    f"availability mask must contain 1 or {batch} values, got {mask.numel()}"
                )
            return mask
        return torch.full((batch,), bool(value), dtype=torch.bool, device=device)

    def _omics_available_mask(self, kwargs, target: torch.Tensor) -> torch.Tensor:
        batch = target.size(0)
        explicit = kwargs.get("omic_available", kwargs.get("omics_available"))
        available = self._batch_bool_mask(
            explicit, batch=batch, device=target.device, default=True
        )
        missing = self._batch_bool_mask(
            kwargs.get("omic_missing"), batch=batch, device=target.device, default=False
        )
        return available & ~missing

    @staticmethod
    def _independent_outer_plan(
        rows: torch.Tensor,
        cols: torch.Tensor,
        num_geometries: int,
    ) -> list[tuple[torch.Tensor, ...]]:
        """§3.1 #4: build the marginal-outer-product plan T = a bᵀ.

        Args:
            rows: ``[B, S, K_w]`` row marginals (per-stage WSI mass).
            cols: ``[B, S, K_o]`` column marginals (per-stage omic mass).
            num_geometries: number of cost geometries per stage (kept to
                preserve the ``plans[stage_idx] = tuple[plan]`` contract).

        Returns:
            ``list[S]`` of ``num_geometries``-tuple of plans, each ``[B, K_w, K_o]``.
        """
        plans: list[tuple[torch.Tensor, ...]] = []
        for stage_idx in range(rows.size(1)):
            stage_plans = []
            for _ in range(num_geometries):
                plan = torch.einsum(
                    "bw,bo->bwo", rows[:, stage_idx], cols[:, stage_idx]
                )
                stage_plans.append(plan)
            plans.append(tuple(stage_plans))
        return plans

    def _plans_from_cost_tensor(self, costs, rows, cols, epoch, *, replay_fixed=False):
        """§3.1 #4: when ``_plan_mode == 'independent'``, replace the
        Sinkhorn-projected plans with the marginal outer product ``T = a bᵀ``.

        The outer product carries no transport information — both modalities
        are projected independently — but still respects the per-stage
        marginals, the multi-stage shape, and the (geometry, plan) tuple
        contract that downstream consumers expect.  Distances are computed
        honestly: the per-stage mean cost mass of the independent plan on
        each cost geometry, averaged across stages.  This makes the audit
        log transparent (you can see the cost mass that *would* be
        transported under the marginals without Sinkhorn alignment).
        """
        if self._plan_mode != "independent":
            return super()._plans_from_cost_tensor(
                costs, rows, cols, epoch, replay_fixed=replay_fixed
            )
        num_geometries = costs.size(2)
        independent_plans = self._independent_outer_plan(
            rows, cols, num_geometries
        )
        # Honest distance reporting: the cost mass the independent plan
        # would transport.  This is purely diagnostic; it never feeds the
        # gradient because the plan is consumed downstream by frozen OT
        # mass terms.
        stage_distances = []
        for stage_idx, stage_plans in enumerate(independent_plans):
            geo_distances = []
            for geo_idx, plan in enumerate(stage_plans):
                geo_distances.append(
                    (plan * costs[:, stage_idx, geo_idx]).sum(dim=(1, 2))
                )
            stage_distances.append(torch.stack(geo_distances).mean())
        distance = torch.stack(stage_distances).mean()
        return independent_plans, distance

    @staticmethod
    def _transport_wsi_to_omic(
        slots_wsi: torch.Tensor,
        factual_plans,
        stage_gate: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if len(factual_plans) != stage_gate.size(1):
            raise ValueError(
                "number of transport stages must match the factual event-gate width"
            )

        transported_stages = []
        for stage_plans in factual_plans:
            if len(stage_plans) < 1:
                raise ValueError("every transport stage must contain at least one geometry")
            consensus_plan = torch.stack(tuple(stage_plans), dim=0).mean(dim=0)
            column_mass = consensus_plan.sum(dim=1).clamp_min(1e-8)
            transported = torch.einsum("bwo,bwd->bod", consensus_plan, slots_wsi)
            transported_stages.append(transported / column_mass.unsqueeze(-1))

        staged = torch.stack(transported_stages, dim=1)
        weights = stage_gate.detach()
        weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
        aggregate = torch.einsum("bs,bsod->bod", weights, staged)
        return aggregate, staged

    @staticmethod
    def _reconstruction_distance(
        prediction: torch.Tensor,
        target: torch.Tensor,
        available: torch.Tensor,
    ) -> torch.Tensor:
        if prediction.shape != target.shape:
            raise ValueError(
                f"reconstruction shape {tuple(prediction.shape)} does not match "
                f"target {tuple(target.shape)}"
            )
        if not bool(available.any()):
            return prediction.sum() * 0.0

        prediction = prediction[available]
        target = target[available].detach()
        prediction = F.layer_norm(prediction, (prediction.size(-1),))
        target = F.layer_norm(target, (target.size(-1),))
        cosine = (1.0 - F.cosine_similarity(prediction, target, dim=-1)).mean()
        robust_l1 = F.smooth_l1_loss(prediction, target)
        return 0.5 * (cosine + robust_l1)

    def reconstruction_losses(
        self,
        *,
        x_omics: torch.Tensor,
        slots_wsi: torch.Tensor,
        slots_omic: torch.Tensor,
        factual_plans,
        factual_gate: torch.Tensor,
        available: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        target = x_omics.detach()
        if self._ablation_disable_self:
            self_loss = slots_omic.new_zeros(())
        else:
            self_prediction = self.pathway_reconstruction_decoder(slots_omic)
            self_loss = self._reconstruction_distance(
                self_prediction, target, available
            )
        if self._ablation_disable_cross:
            cross_loss = slots_omic.new_zeros(())
            transported_wsi = slots_omic.new_zeros(
                slots_omic.size(0), self.spt_num_stages, *slots_omic.shape[1:]
            )
        else:
            if self._cross_mode == "direct":
                # §3.1 #3: bypass OT entirely; feed raw WSI slots directly
                # into the same decoder used by the transport branch.  Both
                # the OT output and the raw slots are [B, K, D] tensors —
                # only the semantic content differs (raw slots live in WSI
                # coordinate space; OT output is the WSI→omic barycentric
                # projection).  No reshape required.
                transported_wsi = slots_wsi
            else:
                transported_wsi, _ = self._transport_wsi_to_omic(
                    slots_wsi, factual_plans, factual_gate
                )
            cross_decoder = (
                self.cross_pathway_reconstruction_decoder
                if self._omics_decoder_mode == "separate"
                else self.pathway_reconstruction_decoder
            )
            cross_prediction = cross_decoder(transported_wsi)
            cross_loss = self._reconstruction_distance(
                cross_prediction, target, available
            )
        # Use the explicit per-branch coefficients rather than the
        # `effective_weight × fraction` decomposition: this guarantees that
        # what the combiner multiplies the loss by is exactly what the audit
        # log stored at construction time (no silent normalisation).  When
        # the branch is disabled both its coefficient and its loss value are
        # zero, so the gradient contribution is also zero.
        total = (
            self.dct_v313_reconstruction_self_coef * self_loss
            + self.dct_v313_reconstruction_cross_coef * cross_loss
        )
        return self_loss, cross_loss, total, transported_wsi

    def wsi_reconstruction_loss(self, slots_wsi, x_wsi_proj, kwargs):
        """Optional WSI self reconstruction; raw zero rows indicate padding."""
        if self.wsi_reconstruction_decoder is None:
            return slots_wsi.new_zeros(())
        if self._v313_revision == "repaired":
            return self.wsi_reconstruction_decoder.reconstruction_loss(
                slots_wsi, x_wsi_proj, self._wsi_valid_patch_mask(kwargs),
            )
        raw = kwargs["x_wsi"]
        valid = raw.detach().ne(0).any(dim=-1)
        explicit = kwargs.get("wsi_patch_mask")
        if explicit is not None:
            explicit = torch.as_tensor(explicit, device=raw.device, dtype=torch.bool)
            if explicit.shape != valid.shape:
                raise ValueError("wsi_patch_mask must have shape [B, N], True=valid")
            valid = valid & explicit
        available = self._batch_bool_mask(
            kwargs.get("wsi_available"), batch=raw.size(0), device=raw.device, default=True,
        )
        missing = self._batch_bool_mask(
            kwargs.get("wsi_missing"), batch=raw.size(0), device=raw.device, default=False,
        )
        valid = valid & (available & ~missing).unsqueeze(-1)
        return self.wsi_reconstruction_decoder.reconstruction_loss(
            slots_wsi, x_wsi_proj, valid,
        )

    def forward(self, **kwargs):
        if self._v313_revision == "repaired":
            self.last_diversity_diagnostics = {}
            self._last_slot_variance = 0.0
            self._last_slot_variance_wsi = 0.0
            self._last_slot_variance_omic = 0.0
            self._last_slot_pair_dist_wsi = 0.0
            self._last_slot_pair_dist_omic = 0.0
        if self._v313_revision == "repaired":
            valid = self._wsi_valid_patch_mask(kwargs)
            # Mask before the MLP as well as before slot pooling: otherwise
            # invalid NaNs can contaminate parameter gradients through 0 * NaN.
            kwargs = dict(kwargs)
            kwargs["_v313_valid_wsi_patches"] = valid
            kwargs["x_wsi"] = kwargs["x_wsi"].masked_fill(~valid.unsqueeze(-1), 0.0)
        if not self.training:
            return super().forward(**kwargs)

        x_wsi_proj = self.wsi_mlp(kwargs["x_wsi"])
        x_omics = self._encode_omics(kwargs)
        if x_omics.ndim != 3 or x_omics.size(1) != int(self.num_pathways):
            raise ValueError(
                "DCT v3.13 expected encoded pathway tokens [B, P, D] with "
                f"P={self.num_pathways}, got {tuple(x_omics.shape)}"
            )

        slots_wsi, slots_omic, _, _ = self._encode_transport_slots(
            x_wsi_proj, x_omics, kwargs
        )
        epoch = int(getattr(self.args, "cur_epoch", kwargs.get("cur_epoch", 0)))
        self._reset_ipcw_memory_for_epoch(epoch)

        factual_costs, rows, cols, _ = self._cost_tensor(slots_wsi, slots_omic)
        factual_plans, ot_distance = self._plans_from_cost_tensor(
            factual_costs, rows, cols, epoch, replay_fixed=False
        )
        self._last_factual_costs = factual_costs.detach()
        self._last_factual_rows = rows.detach()
        self._last_factual_cols = cols.detach()
        self._last_slots_wsi = slots_wsi.detach()
        self._last_slots_omic = slots_omic.detach()

        factual_logits, factual_gate = self._encode_logits_from_plans(
            slots_wsi, slots_omic, factual_plans
        )
        factual_risk = self._risk(factual_logits)

        low_weights = factual_costs.new_zeros(
            factual_costs.size(0), self.spt_num_stages
        )
        high_weights = torch.zeros_like(low_weights)
        ipcw_rank_loss = factual_costs.new_zeros(())
        event_time = kwargs.get("event_time")
        censorship = kwargs.get("c")
        if event_time is not None and censorship is not None:
            low_weights, high_weights = self._stage_membership_weights(
                event_time, censorship
            )
            if self.dct_lambda_ipcw_rank != 0.0:
                ipcw_rank_loss = self._ipcw_pairwise_ranking_loss(
                    factual_logits, event_time, censorship
                )
                self._remember_ipcw_batch(
                    factual_risk,
                    event_time.float().view(-1),
                    censorship.float().view(-1),
                )
            self._update_risk_anchors(
                factual_costs.detach(), low_weights, high_weights
            )

        per_slot_nll = factual_costs.new_zeros(())
        slot_diversity = factual_costs.new_zeros(())
        y = kwargs.get("y")
        if y is not None and event_time is not None and censorship is not None:
            per_slot_nll = self.per_slot_nll_loss(
                slots_wsi, slots_omic, y, event_time, censorship
            )
            slot_diversity = self.slot_diversity_loss(slots_wsi, slots_omic)

        available = self._omics_available_mask(kwargs, x_omics)
        reconstruction_self, reconstruction_cross, reconstruction, transported = (
            self.reconstruction_losses(
                x_omics=x_omics,
                slots_wsi=slots_wsi,
                slots_omic=slots_omic,
                factual_plans=factual_plans,
                factual_gate=factual_gate,
                available=available,
            )
        )
        reconstruction_wsi = self.wsi_reconstruction_loss(slots_wsi, x_wsi_proj, kwargs)
        if self.dct_v313_reconstruction_wsi_coef > 0:
            reconstruction = reconstruction + self.dct_v313_reconstruction_wsi_coef * reconstruction_wsi
        ramp = self._reconstruction_ramp(epoch)
        # The combiner uses the per-branch coefficients directly so the
        # value multiplied into the loss matches the audit log exactly.
        # No additional scaling by ``effective_weight_total`` happens here
        # (that would be a double-down bug).  The ramp still scales both
        # active branches uniformly.
        effective_reconstruction_weight = ramp

        aux_loss = (
            self.dct_lambda_ipcw_rank * ipcw_rank_loss
            + self.dct_v313_lambda_slot_nll_effective * per_slot_nll
            + self.dct_v313_lambda_slot_diversity_effective * slot_diversity
            + effective_reconstruction_weight * reconstruction
        )

        active_stage_fraction = (
            ((low_weights > 0).any(dim=0) & (high_weights > 0).any(dim=0))
            .to(factual_costs.dtype)
            .mean()
        )
        row_entropy = -(
            rows.clamp_min(1e-8) * rows.clamp_min(1e-8).log()
        ).sum(dim=-1) / math.log(max(2, rows.size(-1)))
        col_entropy = -(
            cols.clamp_min(1e-8) * cols.clamp_min(1e-8).log()
        ).sum(dim=-1) / math.log(max(2, cols.size(-1)))

        self._last_reconstruction_self = float(reconstruction_self.detach())
        self._last_reconstruction_cross = float(reconstruction_cross.detach())
        self._last_reconstruction_total = float(reconstruction.detach())
        self._last_reconstruction_ramp = ramp
        self.last_training_losses = {
            "ot": ot_distance.detach(),
            "ipcw_rank": ipcw_rank_loss.detach(),
            "v311_per_slot_nll": per_slot_nll.detach(),
            "v311_slot_diversity": slot_diversity.detach(),
            "v311_slot_variance": factual_costs.new_tensor(self._last_slot_variance),
            "v313_reconstruction_self": reconstruction_self.detach(),
            "v313_reconstruction_cross": reconstruction_cross.detach(),
            "v313_reconstruction_total": reconstruction.detach(),
            "v313_reconstruction_ramp": factual_costs.new_tensor(ramp),
            "v313_reconstruction_weight": factual_costs.new_tensor(
                effective_reconstruction_weight
            ),
            "v313_omics_available_fraction": available.to(factual_costs.dtype).mean(),
            "v313_transported_slot_norm": transported.detach().norm(dim=-1).mean(),
            "active_stage_fraction": active_stage_fraction.detach(),
            "anchor_coverage": self.risk_anchor_seen.to(factual_costs.dtype).mean().detach(),
            "evidence_marginal_entropy": torch.cat(
                [row_entropy.flatten(), col_entropy.flatten()]
            ).mean().detach(),
        }
        if self.dct_v313_reconstruction_wsi_coef > 0:
            self.last_training_losses.update(
                v313_reconstruction_wsi=reconstruction_wsi.detach(),
                v313_reconstruction_self_coef=factual_costs.new_tensor(
                    self.dct_v313_reconstruction_self_coef
                ),
                v313_reconstruction_cross_coef=factual_costs.new_tensor(
                    self.dct_v313_reconstruction_cross_coef
                ),
                v313_reconstruction_total_coef=factual_costs.new_tensor(
                    self.dct_v313_lambda_reconstruction_effective
                ),
                v313_reconstruction_wsi_coef=factual_costs.new_tensor(
                    self.dct_v313_reconstruction_wsi_coef
                ),
            )
        if self._v313_revision == "repaired":
            for modality in ("wsi", "omic"):
                self.last_training_losses.update({
                    "v313_diversity_" + modality + "_" + name: factual_costs.new_tensor(value)
                    for name, value in self.last_diversity_diagnostics.get(modality, {}).items()
                })
            self.last_training_losses["v313_valid_wsi_patch_mean"] = valid.sum(-1).float().mean().detach()
        return factual_logits, aux_loss
