#!/usr/bin/env python3
# -*- encoding: utf-8 -*-
"""Unified training runner for the cleaned SurvOT-Rank framework."""

import os
import sys
import gc
import time
import pickle
import traceback
import shutil
import warnings
import copy
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import torch
import torch.optim as optim

# Paths
TRAINING_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(os.path.dirname(TRAINING_DIR))

from survot_rank.training.paths import ensure_compat_runtime_in_path  # noqa
ensure_compat_runtime_in_path()

# Packaged legacy dataset, loss, and metric utilities.
from dataset.dataset_survival import SurvivalDatasetFactory, SurvivalDataset, _collate_pathways
from utils.loss_func import NLLSurvLoss, SurvPLE, RankLoss, SinkhornSurvLoss
from utils.general_utils import (
    _get_start_end, _prepare_for_experiment, _save_pkl, _print_network
)


def set_global_seed(seed):
    """鍏ㄥ眬 RNG 澶嶄綅浠ヤ繚璇佸悓 seed 浜х敓鐩稿悓鍒濆鍖栨潈閲?

    NOTE: cuDNN benchmark=True (榛樿)锛屼笉寮哄埗 deterministic銆?    鍘熷 V45 (2026-06-30) 浣跨敤闈炵‘瀹氭€?cuDNN 绠楁硶璺戝嚭 0.7105锛?    寮哄埗 deterministic=True 浼氱郴缁熸€ч檷浣?~0.01-0.02锛屾晠淇濈暀闈炵‘瀹氭€с€?    DataLoader generator 宸蹭繚璇?batch 椤哄簭纭畾鎬с€?    """
    import random
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    # 鎭㈠鍘熷 V45 鐨?cuDNN 閰嶇疆锛歜enchmark=True 鍏佽閫夋嫨鏈€蹇畻娉?    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.enabled = True
from utils.core_utils import (
    _process_data_and_forward, _calculate_risk, _update_arrays,
    _calculate_metrics, _extract_survival_metadata
)
from sksurv.exceptions import NoComparablePairException
from sksurv.metrics import concordance_index_censored

# SurvOT-Rank model factory.
from survot_rank.training.model_factory import get_model
from survot_rank.training.extended_args import process_args_extended
from survot_rank.training.sparse_event import (
    EarlyStoppingController,
    make_event_aware_sampler,
    make_stratified_event_batch_sampler,
)


def safe_write_line(log_file, message):
    try:
        log_file.write(message + "\n")
    except OSError as error:
        if getattr(error, "errno", None) == 28:
            print(f"[WARN] 鏃ュ織鍐欏叆澶辫触锛岀鐩樼┖闂翠笉瓒? {error}")
        else:
            raise


def safe_flush(log_file):
    try:
        log_file.flush()
    except OSError as error:
        if getattr(error, "errno", None) == 28:
            print(f"[WARN] 鏃ュ織 flush 澶辫触锛岀鐩樼┖闂翠笉瓒? {error}")
        else:
            raise


def safe_to_csv(records, csv_path):
    try:
        pd.DataFrame(records).to_csv(csv_path, index=False)
        return True
    except OSError as error:
        if getattr(error, "errno", None) == 28:
            print(f"[WARN] 璺宠繃鍐欏叆 {csv_path}锛岀鐩樼┖闂翠笉瓒? {error}")
            return False
        raise


def safe_pickle_dump(obj, output_path):
    try:
        with open(output_path, "wb") as file_obj:
            pickle.dump(obj, file_obj)
        return True
    except OSError as error:
        if getattr(error, "errno", None) == 28:
            print(f"[WARN] 璺宠繃鍐欏叆 {output_path}锛岀鐩樼┖闂翠笉瓒? {error}")
            return False
        raise


def safe_torch_save(state_dict, output_path):
    try:
        torch.save(state_dict, output_path)
        return True
    except OSError as error:
        if getattr(error, "errno", None) == 28:
            print(f"[WARN] 璺宠繃鍐欏叆 {output_path}锛岀鐩樼┖闂翠笉瓒? {error}")
            return False
        raise


def get_free_space_gb(path):
    usage = shutil.disk_usage(path)
    return usage.free / (1024 ** 3)


def ensure_min_free_space(path, min_free_gb, context):
    free_gb = get_free_space_gb(path)
    if free_gb < min_free_gb:
        raise RuntimeError(
            f"{context} has insufficient free space: {free_gb:.2f}GB available, "
            f"requires at least {min_free_gb:.2f}GB. Results path: {path}"
        )
    return free_gb


# ============================================================
# 妯″瀷涓庝紭鍖栧櫒鍒濆鍖?# ============================================================

def init_model_for_method(args, dataset_factory, *, write_audit=True):
    """
    Build the selected SurvOT-Rank method.
    """
    if args.rna_format == "RNASeq":
        omics_input_dim = dataset_factory.num_genes if dataset_factory.num_genes is not None \
                          else dataset_factory.omic_sizes
    elif args.rna_format == "GeneEmbedding":
        omics_input_dim = 768
    else:
        omics_input_dim = None

    args.omic_sizes = dataset_factory.omic_sizes
    args.omic_names = dataset_factory.omic_names
    args.pathway_names = getattr(dataset_factory, 'pathway_names', None)

    print(f"[init] loading SurvOT-Rank method: {args.survot_method}")
    model = get_model(
        method=args.survot_method,
        args=args,
        omic_input_dim=omics_input_dim,
        omic_names=args.omic_names,
        pathway_names=args.pathway_names,
    )

    if write_audit and getattr(model, "_v313_revision", "legacy") == "repaired":
        from survot_rank.research.methods.legacy.experimental.dct_v313_transport_reconstruction.provenance import write_implementation_audit
        audit_path = write_implementation_audit(model, args)
        print(f"[init] effective v3.13 implementation audit: {audit_path}")

    if torch.cuda.is_available():
        model = model.to(torch.device('cuda'))

    _print_network(args.results_dir, model)
    return model


def init_loss_function(args):
    if args.bag_loss == 'nll_surv':
        method = getattr(args, "survot_method", None) or getattr(args, "newslot_method", None)
        if method in {"dct_v2", "dct_v2_standalone", "dct_v21", "dct_v2_1", "dct_v22", "dct_v2_2", "dct_v23", "dct_v2_3"}:
            from survot_rank.research.methods.dct_v2.losses import StableNLLSurvLoss
            return StableNLLSurvLoss(alpha=args.alpha_surv)
        if method in {"dct_v315", "dct_v315_residual_transport"}:
            from survot_rank.research.methods.legacy.experimental.dct_v315_residual_transport.losses import StableNLLSurvLoss
            return StableNLLSurvLoss(alpha=args.alpha_surv)
        if method in {"dct_v314", "dct_v314_masked_transport_reconstruction"}:
            from survot_rank.research.methods.legacy.experimental.dct_v314_masked_transport_reconstruction.losses import StableNLLSurvLoss
            return StableNLLSurvLoss(alpha=args.alpha_surv)
        return NLLSurvLoss(alpha=args.alpha_surv)
    elif args.bag_loss == 'cox_surv':
        return SurvPLE()
    elif args.bag_loss == 'rank_surv':
        return RankLoss()
    elif args.bag_loss == 'sinkhorn_surv':
        return SinkhornSurvLoss(alpha=args.alpha_surv)
    else:
        raise NotImplementedError


def init_optimizer(args, model):
    if args.opt == "adam":
        return optim.Adam(model.parameters(), lr=args.lr)
    elif args.opt == 'sgd':
        return optim.SGD(model.parameters(), lr=args.lr, momentum=0.9, weight_decay=args.reg)
    elif args.opt == "adamW":
        return optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.reg)
    else:
        raise NotImplementedError


def init_scheduler(args, optimizer):
    # warmup_epochs>0 时：前 warmup_epochs 个 epoch 用 LinearLR 从 0.1*lr 线性升到 lr，
    # 之后接 Cosine。避免 cosine 在 epoch 0 就用峰值 lr 在 batch=4 上做又大又抖的跳跃，
    # 这是"best 出现在 epoch 0-1"的优化层面主因之一。默认 0 = 原行为。
    warmup_epochs = int(getattr(args, "warmup_epochs", 0) or 0)
    if args.scheduler == "step":
        return optim.lr_scheduler.StepLR(optimizer, step_size=args.step_size)
    elif args.scheduler == "cosine":
        eta_min = getattr(args, "eta_min", 0.0)
        cosine_epochs = max(1, args.max_epochs - warmup_epochs)
        cosine = optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=cosine_epochs, eta_min=eta_min
        )
        if warmup_epochs > 0:
            warm = optim.lr_scheduler.LinearLR(
                optimizer, start_factor=0.1, end_factor=1.0, total_iters=warmup_epochs
            )
            return optim.lr_scheduler.SequentialLR(
                optimizer, schedulers=[warm, cosine], milestones=[warmup_epochs]
            )
        return cosine
    else:
        raise NotImplementedError


# ============================================================
# 鏁版嵁鍔犺浇
# ============================================================

def get_split(args, dataset_factory, fold):
    """Return the four datasets/loaders a fold needs.

    §3.1 #5: under ``evaluation_protocol=outer_test`` the original
    five-fold ``val`` is fixed as the outer test, and the original
    ``train`` is split 80/20 (stratified by event, ``split_seed=3``)
    into ``inner_train`` and ``inner_val``.  All binning, censoring
    reference, and OT edge fitting use ``inner_train`` ONLY — the
    outer test never touches the model state during training.

    Returns:
        (train_data, val_data, train_loader, val_loader) for legacy_val.
        (inner_train_data, inner_val_data, inner_train_loader, inner_val_loader)
            for outer_test — ``val_data`` here is the inner_val (used for
            checkpoint selection); the outer test set is *not* returned
            because it must be evaluated exactly once after training
            (see ``evaluate_outer_test`` below).
    """
    split_path = os.path.join(
        dataset_factory.data_path,
        "splits", dataset_factory.which_splits, dataset_factory.study,
        f"fold_{fold}.csv",
    )
    split_df = pd.read_csv(split_path)
    # V51 fix (2026-07-14): preserve one shared global bin definition.
    # Per-fold quantile binning coupled OT plans and event embeddings to
    # incompatible target bins; keep the factory-level global bins by default.
    # dataset_factory.fit_label_bins(split_df["train"].dropna().tolist())

    evaluation_protocol = getattr(args, "evaluation_protocol", "legacy_val")
    if evaluation_protocol not in ("legacy_val", "outer_test"):
        raise ValueError(
            f"evaluation_protocol must be 'legacy_val' or 'outer_test', got "
            f"{evaluation_protocol!r}"
        )
    # Which split column drives the bin-fitting?  In legacy_val it is the
    # parent train; in outer_test it is inner_train only — the outer test
    # must never leak into the bin edges.
    if evaluation_protocol == "outer_test":
        required_columns = {"inner_train", "inner_val", "outer_test"}
        missing_columns = required_columns - set(split_df.columns)
        if missing_columns:
            raise KeyError(
                f"evaluation_protocol=outer_test requires split CSV columns "
                f"{sorted(required_columns)}; missing {sorted(missing_columns)} "
                f"in {split_path}.  Generate them with "
                f"`python -m survot_rank.training.outer_test_split --which_splits "
                f"{dataset_factory.which_splits} --outer_which_splits "
                f"{dataset_factory.which_splits}_outer_test_seed<seed>`."
            )
        fit_column = "inner_train"
    else:
        fit_column = "train"

    if getattr(args, "fit_bins_on_train", False):
        # Discrete-time labels are part of the supervised target.  Fit their
        # quantile edges before constructing either dataset so validation times
        # cannot influence the fold's label representation.
        dataset_factory.fit_label_bins(split_df[fit_column].dropna().tolist())

    wsi_path = os.path.join(
        args.data_root_dir,
        dataset_factory.study,
        getattr(args, "wsi_encoder", "uni"),
        "pt_files",
    )
    on_missing_wsi = getattr(args, "on_missing_wsi", "error")
    if evaluation_protocol == "outer_test":
        train_data = SurvivalDataset(
            dataset_factory, wsi_path, 'inner_train', fold, args.encoding_dim,
            on_missing_wsi=on_missing_wsi,
        )
        test_data = SurvivalDataset(
            dataset_factory, wsi_path, 'inner_val', fold, args.encoding_dim,
            on_missing_wsi=on_missing_wsi,
        )
    else:
        train_data = SurvivalDataset(
            dataset_factory, wsi_path, 'train', fold, args.encoding_dim,
            on_missing_wsi=on_missing_wsi,
        )
        test_data = SurvivalDataset(
            dataset_factory, wsi_path, 'val', fold, args.encoding_dim,
            on_missing_wsi=on_missing_wsi,
        )

    collate_pathways = _collate_pathways
    if _v23_enabled(args):
        if args.rna_format != "Pathways":
            raise ValueError("DCT v2.3 requires raw-gene Pathways inputs")
        _configure_v23_training_data(args, dataset_factory, train_data, split_df, split_path)
        from survot_rank.research.methods.dct_v23.calibration import (
            PatientIdentifiedDataset, collate_identified_pathways,
        )
        train_data = PatientIdentifiedDataset(train_data)
        test_data = PatientIdentifiedDataset(test_data)
        collate_pathways = collate_identified_pathways

    # 鍚敤澶氳繘绋嬫暟鎹姞杞藉拰椤甸攣瀹氬唴瀛樹互鍔犻€?GPU 璁粌
    num_workers = getattr(args, 'num_workers', 4)
    pin_memory = True
    event_sampling_fraction = float(getattr(args, "event_sampling_fraction", 0.0) or 0.0)
    event_stratified_batches = bool(getattr(args, "event_stratified_batches", False))
    if event_sampling_fraction > 0.0 and event_stratified_batches:
        raise ValueError(
            "event_sampling_fraction and event_stratified_batches cannot be enabled together"
        )
    train_sampler = None
    if event_sampling_fraction > 0.0:
        train_sampler = make_event_aware_sampler(
            train_data.label_df[dataset_factory.censorship_var].to_numpy(),
            event_sampling_fraction,
            seed=int(getattr(args, "seed", 3)) + 1009 * int(fold),
            num_samples=len(train_data),
        )
        no_event_probability = (1.0 - event_sampling_fraction) ** int(args.batch_size)
        print(
            f"[data] event-aware sampling target={event_sampling_fraction:.3f} "
            f"expected_events_per_batch={event_sampling_fraction * int(args.batch_size):.2f} "
            f"P(no_event_batch)={no_event_probability:.3f}"
        )

    train_batch_sampler = None
    if event_stratified_batches:
        train_batch_sampler = make_stratified_event_batch_sampler(
            train_data.label_df[dataset_factory.censorship_var].to_numpy(),
            int(args.batch_size),
            seed=int(getattr(args, "seed", 3)) + 1009 * int(fold),
        )
        sampler_event_count = int(
            (train_data.label_df[dataset_factory.censorship_var] < 0.5).sum()
        )
        event_batches = min(sampler_event_count, len(train_batch_sampler))
        print(
            f"[data] patient-complete stratified batches enabled "
            f"event_batches<={event_batches}/{len(train_batch_sampler)} "
            f"replacement=False"
        )

    if args.rna_format == "Pathways" or args.rna_format == "RankedGenes":
        if train_batch_sampler is not None:
            train_loader = torch.utils.data.DataLoader(
                train_data, batch_sampler=train_batch_sampler, num_workers=num_workers,
                collate_fn=collate_pathways, pin_memory=pin_memory,
            )
        else:
            train_loader = torch.utils.data.DataLoader(
                train_data, batch_size=args.batch_size, shuffle=train_sampler is None,
                sampler=train_sampler, num_workers=num_workers,
                drop_last=True, collate_fn=collate_pathways, pin_memory=pin_memory,
                generator=torch.Generator().manual_seed(getattr(args, 'seed', 3))
            )
        test_loader = torch.utils.data.DataLoader(
            test_data, batch_size=1, shuffle=False, num_workers=num_workers,
            collate_fn=collate_pathways, pin_memory=pin_memory
        )
    else:
        if train_batch_sampler is not None:
            train_loader = torch.utils.data.DataLoader(
                train_data, batch_sampler=train_batch_sampler,
                num_workers=num_workers, pin_memory=pin_memory,
            )
        else:
            train_loader = torch.utils.data.DataLoader(
                train_data, batch_size=args.batch_size, shuffle=train_sampler is None,
                sampler=train_sampler,
                num_workers=num_workers, drop_last=True, pin_memory=pin_memory,
                generator=torch.Generator().manual_seed(getattr(args, 'seed', 3))
            )
        test_loader = torch.utils.data.DataLoader(
            test_data, batch_size=1, shuffle=False, num_workers=num_workers, pin_memory=pin_memory
        )
    train_labels = train_data.label_df
    val_labels = test_data.label_df
    train_events = int((train_labels[dataset_factory.censorship_var] < 0.5).sum())
    val_events = int((val_labels[dataset_factory.censorship_var] < 0.5).sum())
    train_bins = train_labels["label"].value_counts().sort_index().to_dict()
    val_bins = val_labels["label"].value_counts().sort_index().to_dict()
    print(
        f"[data] train={len(train_data)} val={len(test_data)} "
        f"train_events={train_events} val_events={val_events} "
        f"train_bins={train_bins} val_bins={val_bins} "
        f"event_stratified_batches={event_stratified_batches} "
        f"num_workers={num_workers} pin_memory={pin_memory}"
    )
    return train_data, test_data, train_loader, test_loader


# ============================================================
# 璁粌 / 璇勪及寰幆
# ============================================================

def compose_batch_objective(loss_surv, auxiliary_loss, batch_size):
    """Compose the shared mean survival loss and a method auxiliary loss."""

    if int(batch_size) < 1:
        raise ValueError(f"batch_size must be positive, received {batch_size!r}")
    return loss_surv / int(batch_size) + auxiliary_loss


def _v22_monitoring_enabled(args):
    """Keep the candidate's expanded CSV schema out of historical methods."""
    return getattr(args, "survot_method", None) in {"dct_v22", "dct_v2_2", "dct_v23", "dct_v2_3"}


def _v23_enabled(args):
    return getattr(args, "survot_method", None) in {"dct_v23", "dct_v2_3"}


def _configure_v23_training_data(args, factory, train_data, split_df, split_path):
    """Fit raw-gene statistics and bind teacher artifacts to this training fold."""
    import hashlib
    from pathlib import Path
    from survot_rank.research.methods.dct_v23.calibration import training_reference, load_calibration, raw_expression_matrix
    train_ids = train_data.label_df["case id"].astype(str).tolist()
    train_column = "inner_train" if getattr(args, "evaluation_protocol", "legacy_val") == "outer_test" else "train"
    declared = split_df[train_column].dropna().astype(str).tolist()
    if len(declared) != len(set(declared)) or set(declared) != set(train_ids):
        raise ValueError("DCT v2.3 requires exact declared training-patient coverage")
    excluded_columns = ("inner_val", "outer_test") if train_column == "inner_train" else ("val",)
    excluded = {str(x) for col in excluded_columns for x in split_df[col].dropna()}
    if set(train_ids) & excluded:
        raise ValueError("DCT v2.3 training and evaluation patients overlap")
    reference = training_reference(factory, train_ids)
    for name in ("pathway_gene_ids", "gene_ids", "raw_gene_mean", "raw_gene_std", "train_patient_ids"):
        setattr(args, f"dct_v23_{name}", reference[name])
    args._dct_v23_gain_payload = None
    if getattr(args, "dct_v23_reconstruction_mode", "off") == "gain_calibrated":
        directory = getattr(args, "dct_v23_calibration_dir", None)
        if not directory:
            raise ValueError("gain_calibrated requires a prepared calibration directory")
        path = Path(directory) / f"fold_{train_data.fold}.json"
        args._dct_v23_gain_payload = load_calibration(path, patient_ids=train_ids, excluded_ids=excluded,
            pathway_gene_ids=reference["pathway_gene_ids"], raw_expression_sha256=reference["raw_expression_sha256"],
            split_sha256=hashlib.sha256(Path(split_path).read_bytes()).hexdigest(),
            encoding_dim=args.encoding_dim, wsi_encoder=getattr(args, "wsi_encoder", "uni"),
            raw_expression=raw_expression_matrix(factory, train_ids, reference["gene_ids"]))


def _forward_training_batch(args, model, data, device, *, test=False):
    if _v23_enabled(args):
        from survot_rank.research.methods.dct_v23.calibration import process_identified_batch
        return process_identified_batch(args, model, data, device, test=test)
    return _process_data_and_forward(args, model, data, device, test=test)


class _PatientWeightedMonitoring:
    """Aggregate detached batch means over the patients actually represented.

    Modality-specific statistics use the model's valid-patient counts; missing
    modalities must not dilute their averages. Counts are summed, not averaged.
    A missing/non-finite observation is excluded, never silently replaced by 0.
    """

    _count_keys = {
        "wsi_monitor_patient_count", "omics_monitor_patient_count",
        "transport_monitor_patient_count",
        "relation_cost_gradient_sample_count",
    }
    _transport_keys = {
        "plan_independence_l1_normalized", "local_readout_norm",
    }

    def __init__(self):
        self.sums = {}
        self.weights = {}
        self.counts = {}

    @staticmethod
    def _number(value):
        if isinstance(value, torch.Tensor):
            if value.numel() != 1:
                return None
            value = value.detach().item()
        try:
            result = float(value)
        except (TypeError, ValueError):
            return None
        return result if np.isfinite(result) else None

    def add(self, metrics, batch_samples, *, excluded=(), metric_weights=None):
        values = {
            key: self._number(value) for key, value in (metrics or {}).items()
            if key not in excluded
        }
        for key, value in values.items():
            if value is None:
                continue
            if key in self._count_keys:
                if value >= 0:
                    self.counts[key] = self.counts.get(key, 0.0) + value
                continue
            count_key = None
            if key.startswith("wsi_"):
                count_key = "wsi_monitor_patient_count"
            elif key.startswith("omics_"):
                count_key = "omics_monitor_patient_count"
            elif key.startswith("transport_") or key in self._transport_keys:
                count_key = "transport_monitor_patient_count"
            weight = values.get(count_key) if count_key is not None else float(batch_samples)
            if metric_weights is not None and key in metric_weights:
                weight = self._number(metric_weights[key])
            # Without an explicit modality count, that modality's mean cannot
            # be interpreted reliably in a partially observed batch.
            if weight is None or weight <= 0:
                continue
            self.sums[key] = self.sums.get(key, 0.0) + value * weight
            self.weights[key] = self.weights.get(key, 0.0) + weight

    def means(self):
        result = {
            key: value / self.weights[key] for key, value in self.sums.items()
        }
        result.update(self.counts)
        return result


def _build_v22_train_evaluation_loader(args, train_data):
    """Visit current training patients once using the validation bag policy.

    A shallow copy preserves its training-patient label frame; changing only
    split_key selects the existing evenly spaced patch policy without loading
    validation patients. The original dataset/sampler is untouched. A private
    generator prevents DataLoader iterator creation consuming the training RNG.
    """
    evaluation_data = copy.copy(train_data)
    collate = _collate_pathways if args.rna_format in ("Pathways", "RankedGenes") else None
    if _v23_enabled(args):
        from survot_rank.research.methods.dct_v23.calibration import PatientIdentifiedDataset, collate_identified_pathways
        if not isinstance(train_data, PatientIdentifiedDataset):
            raise ValueError("DCT v2.3 training snapshots require identified datasets")
        evaluation_source = copy.copy(train_data.dataset)
        evaluation_source.split_key = "val"
        evaluation_data = PatientIdentifiedDataset(evaluation_source)
        collate = collate_identified_pathways
    elif isinstance(evaluation_data, SurvivalDataset):
        evaluation_data.split_key = "val"
    return torch.utils.data.DataLoader(
        evaluation_data, batch_size=1, shuffle=False, drop_last=False,
        num_workers=int(getattr(args, "num_workers", 0)),
        collate_fn=collate,
        pin_memory=torch.cuda.is_available(),
        generator=torch.Generator().manual_seed(int(getattr(args, "seed", 3))),
    )


def _validate_v22_evaluation_loader(loader):
    """The legacy batch payload has no case IDs after collate drops samples.

    Sequential batch=1 makes each surviving output's source index recoverable.
    Other sampling/batching policies need explicit returned case IDs, which the
    current dataset interface does not provide; reject them instead of guessing.
    """
    if (getattr(loader, "batch_size", None) != 1
            or not isinstance(getattr(loader, "sampler", None), torch.utils.data.SequentialSampler)
            or bool(getattr(loader, "drop_last", False))):
        raise ValueError(
            "DCT v2.2 evaluation requires a sequential batch_size=1 loader "
            "with drop_last=False to preserve patient IDs after skipped samples"
        )


def _evaluate_v22_train_snapshot(args, dataset_factory, model, loader, loss_fn, survival_train):
    """Freeze one checkpoint in eval mode; never configure references or rank memory."""
    import random
    modes = [(module, module.training) for module in model.modules()]
    rng_python = random.getstate()
    rng_numpy = np.random.get_state()
    rng_torch = torch.get_rng_state()
    rng_cuda = torch.cuda.get_rng_state_all() if torch.cuda.is_available() and torch.cuda.is_initialized() else None
    try:
        result = evaluate(args, dataset_factory, model, loader, loss_fn, survival_train)
        metrics = dict(getattr(model, "last_evaluation_monitoring_metrics", {}))
        metrics["cindex"] = result[1]
        return metrics
    finally:
        # Preserve mixed module flags as well as the top-level flag.
        for module, training in modes:
            module.training = training
        random.setstate(rng_python)
        np.random.set_state(rng_numpy)
        torch.set_rng_state(rng_torch)
        if rng_cuda is not None:
            torch.cuda.set_rng_state_all(rng_cuda)


def train_one_epoch(args, epoch, model, loader, optimizer, scheduler, loss_fn, log_file):
    from tqdm import tqdm
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.train()
    args.cur_epoch = epoch

    total_loss = 0.0
    seen_samples = 0
    method_diagnostic_sums = {}
    method_diagnostic_batches = 0
    v22_monitoring = _v22_monitoring_enabled(args)
    monitoring = _PatientWeightedMonitoring() if v22_monitoring else None
    all_risk_scores, all_censorships, all_event_times = [], [], []

    # 梯度累积：batch=4 时通过累积 grad_accum_steps 个 micro-batch 再更新，
    # 把"有效 batch"提到 4*grad_accum_steps（如 8 -> 32）。这是解决"NLL 在
    # 小 batch 上过拟合、摧毁全局风险排序、导致 best 出现在最前几个 epoch"的
    # 最高杠杆修复：有效 batch 变大后梯度方差下降，模型能学到全局一致的排序，
    # 峰值会后移到中后段。默认 grad_accum_steps=1 = 原行为。
    grad_accum = int(getattr(args, "grad_accum_steps", 1) or 1)
    accumulation_steps = 32 if args.batch_size == 1 else max(1, grad_accum)
    total_batches = len(loader)
    smk = int(getattr(args, "max_smoke_batches", 0) or 0)
    n_batches = smk if smk > 0 else total_batches

    pbar = tqdm(enumerate(loader), total=n_batches,
                desc=f"  [Fold {args.cur_fold}] Epoch {epoch+1}/{args.max_epochs}",
                ncols=120, leave=False, dynamic_ncols=True)
    for batch_idx, data in pbar:
        if data is None:
            # Collate function dropped every sample (all corrupt/missing).
            # Skip and continue to the next batch.
            continue
        if v22_monitoring:
            model.last_monitoring_metrics = {}
            model.last_monitoring_metric_weights = {}
        out, y_disc, event_time, c = _forward_training_batch(args, model, data, device)
        logits, slot_loss = out

        for name, value in getattr(model, "last_training_losses", {}).items():
            method_diagnostic_sums[name] = method_diagnostic_sums.get(name, 0.0) + float(value.item())
        if getattr(model, "last_training_losses", None):
            method_diagnostic_batches += 1

        if args.bag_loss == "cox_surv":
            loss_surv = loss_fn(logits, event_time, c)
        else:
            loss_surv = loss_fn(logits, y_disc, event_time, c)
        batch_objective = compose_batch_objective(
            loss_surv,
            slot_loss,
            y_disc.shape[0],
        )
        if v22_monitoring:
            batch_samples = int(y_disc.shape[0])
            model_monitoring = getattr(model, "last_monitoring_metrics", {})
            # Sampled probe gradients also appear in last_training_losses.
            # The model's per-key sample weights are authoritative for these;
            # adding both streams would double count them with different B.
            monitoring.add(getattr(model, "last_training_losses", {}), batch_samples,
                           excluded=model_monitoring.keys())
            monitoring.add(model_monitoring, batch_samples,
                           excluded={"global_nll", "auxiliary_total"},
                           metric_weights=getattr(model, "last_monitoring_metric_weights", {}))
            monitoring.add({
                "optimization_main_nll": loss_surv.detach() / batch_samples,
                "optimization_auxiliary_total": slot_loss,
                "optimization_total_objective": batch_objective.detach(),
            }, batch_samples)
        loss = batch_objective / accumulation_steps
        loss.backward()
        if hasattr(model, "dct_lambda_listwise"):
            finite_gradient_values = [
                torch.isfinite(parameter.grad).to(torch.float32).mean()
                for parameter in model.parameters()
                if parameter.grad is not None
            ]
            finite_gradient_fraction = (
                torch.stack(finite_gradient_values).mean().item()
                if finite_gradient_values
                else 0.0
            )
            method_diagnostic_sums["listwise_finite_gradients"] = (
                method_diagnostic_sums.get("listwise_finite_gradients", 0.0)
                + finite_gradient_fraction
            )

        # 统一的累积更新：每 accumulation_steps 个 micro-batch 更新一次，
        # 并在 epoch 最后一个 batch 冲刷残余梯度（避免尾部样本梯度丢失）。
        grad_clip = float(getattr(args, "grad_clip_norm", 0.0) or 0.0)
        is_last_batch = (batch_idx + 1) == n_batches
        if (batch_idx + 1) % accumulation_steps == 0 or is_last_batch:
            if grad_clip > 0.0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
            optimizer.step()
            optimizer.zero_grad()

        # Report the actual per-sample objective. The old code accumulated the
        # gradient-scaled batch loss and divided it by the dataset size again,
        # making the displayed train loss depend on batch/accumulation settings.
        batch_samples = int(y_disc.shape[0])
        total_loss += float(batch_objective.item()) * batch_samples
        seen_samples += batch_samples
        risk, _ = _calculate_risk(logits)
        all_risk_scores, all_censorships, all_event_times = _update_arrays(
            all_risk_scores, all_censorships, all_event_times,
            event_time, c, risk, data
        )

        pbar.set_postfix(loss=f"{batch_objective.item():.3f}", surv=f"{loss_surv.item():.3f}",
                         batch=f"{batch_idx+1}/{total_batches}", refresh=False)
        if batch_idx % 10 == 0:
            msg = (
                f"  batch:{batch_idx} loss:{batch_objective.item():.4f} "
                f"surv:{loss_surv.item():.4f}"
            )
            print(msg, flush=True)
            safe_write_line(log_file, msg)
        if smk > 0 and (batch_idx + 1) >= smk:
            pbar.set_postfix(loss=f"{batch_objective.item():.3f}", surv=f"{loss_surv.item():.3f}",
                             batch=f"{batch_idx+1}/{total_batches}", status="smoke-stop", refresh=False)
            msg = f"  [smoke] stop train epoch after {batch_idx + 1} batch(es)"
            print(msg, flush=True)
            safe_write_line(log_file, msg)
            break
    pbar.close()

    scheduler.step()

    total_loss /= max(seen_samples, 1)
    all_risk_scores = np.concatenate(all_risk_scores, axis=0)
    all_censorships = np.concatenate(all_censorships, axis=0)
    all_event_times = np.concatenate(all_event_times, axis=0)
    # 训练 C-index 只是诊断量，不参与反传或模型选择。事件稀疏、小 batch 或
    # smoke 模式下这一批可能没有任何可比较的样本对，sksurv 会抛
    # NoComparablePairException；此前该异常会一路冒泡并让整个 fold 失败
    # （例如 ArcSurv smoke 的 fold2）。这里降级为 NaN 并继续训练。
    try:
        c_index = concordance_index_censored(
            (1 - all_censorships).astype(bool), all_event_times,
            all_risk_scores, tied_tol=1e-08
        )[0]
    except NoComparablePairException:
        c_index = float("nan")
        msg = (
            f"  [warn] epoch {epoch} 训练集无可比较样本对，train_cindex 记为 nan"
        )
        print(msg, flush=True)
        safe_write_line(log_file, msg)

    diagnostics = {
        name: value / max(method_diagnostic_batches, 1)
        for name, value in method_diagnostic_sums.items()
    }
    if v22_monitoring:
        diagnostics = monitoring.means()
        diagnostics["optimization_cindex"] = float(c_index)
        diagnostics["optimization_patient_count"] = seen_samples
    def _fmt(value):
        # Use higher precision for tiny metrics (variances can be ~1e-4)
        if abs(value) < 0.001:
            return f"{value:.2e}"
        return f"{value:.4f}"
    diagnostic_text = "".join(
        f"  {name}={_fmt(value)}" for name, value in diagnostics.items()
    )
    msg = (
        f"[Epoch {epoch}] train_loss={total_loss:.4f}  "
        f"train_cindex={c_index:.4f}{diagnostic_text}"
    )
    print(msg)
    safe_write_line(log_file, msg)
    return diagnostics


def evaluate_outer_test(args, dataset_factory, fold, model_state_path, log_file):
    """§3.1 #5: evaluate the best inner-train checkpoint on the outer test.

    Loads ``model_state_path`` (the inner-train best checkpoint), constructs
    the outer-test loader from the same split CSV used during training,
    and runs ``evaluate`` exactly once.  The test cohort is NEVER seen
    during training and NEVER participates in checkpoint selection.

    Returns:
        Tuple ``(test_results, test_c, test_c_ipcw, test_BS, test_IBS,
        test_iauc, test_loss)`` mirroring the ``evaluate`` contract so
        downstream bookkeeping can treat outer-test metrics identically
        to legacy val metrics.
    """
    if getattr(args, "evaluation_protocol", "legacy_val") != "outer_test":
        raise ValueError(
            "evaluate_outer_test called with evaluation_protocol="
            f"{getattr(args, 'evaluation_protocol', 'legacy_val')!r}; "
            "this function is only valid under outer_test"
        )
    wsi_path = os.path.join(
        args.data_root_dir,
        dataset_factory.study,
        getattr(args, "wsi_encoder", "uni"),
        "pt_files",
    )
    on_missing_wsi = getattr(args, "on_missing_wsi", "error")
    outer_test_data = SurvivalDataset(
        dataset_factory, wsi_path, 'outer_test', fold, args.encoding_dim,
        on_missing_wsi=on_missing_wsi,
    )
    outer_test_collate = _collate_pathways
    if _v23_enabled(args):
        from survot_rank.research.methods.dct_v23.calibration import PatientIdentifiedDataset, collate_identified_pathways
        outer_test_data = PatientIdentifiedDataset(outer_test_data)
        outer_test_collate = collate_identified_pathways
    if args.rna_format == "Pathways" or args.rna_format == "RankedGenes":
        outer_test_loader = torch.utils.data.DataLoader(
            outer_test_data, batch_size=1, shuffle=False,
            num_workers=getattr(args, 'num_workers', 4), pin_memory=True,
            collate_fn=outer_test_collate,
        )
    else:
        outer_test_loader = torch.utils.data.DataLoader(
            outer_test_data, batch_size=1, shuffle=False,
            num_workers=getattr(args, 'num_workers', 4), pin_memory=True,
        )

    # Outer test patients are unrelated to inner_train / inner_val; the
    # survival reference is therefore the inner-train-derived one, not
    # anything computed from the outer test set.
    train_labels = _load_inner_train_labels(args, dataset_factory, fold)
    survival_train = _extract_survival_metadata(dataset_factory, train_labels)

    # Build the model on the same constructor used for training, then load
    # the inner-train best checkpoint.
    if getattr(args, "dct_v313_revision", "legacy") == "repaired":
        model = init_model_for_method(args, dataset_factory, write_audit=False)
    else:
        model = init_model_for_method(args, dataset_factory)
    state_dict = torch.load(model_state_path, map_location="cpu")
    model.load_state_dict(state_dict)

    loss_fn = init_loss_function(args)
    test_events = int(
        (outer_test_data.label_df[dataset_factory.censorship_var] < 0.5).sum()
    )
    safe_write_line(
        log_file,
        f"[outer-test] fold={fold} n={len(outer_test_data)} events={test_events}",
    )

    results, test_c, test_c_ipcw, test_BS, test_IBS, test_iauc, test_loss = evaluate(
        args, dataset_factory, model, outer_test_loader, loss_fn, survival_train,
    )
    msg = (
        f"[outer-test] fold={fold} cindex={test_c:.4f} ipcw={test_c_ipcw:.4f} "
        f"IBS={test_IBS:.4f} iauc={test_iauc:.4f}"
    )
    print(msg)
    safe_write_line(log_file, msg)
    safe_flush(log_file)
    return results, test_c, test_c_ipcw, test_BS, test_IBS, test_iauc, test_loss


def _load_inner_train_labels(args, dataset_factory, fold):
    """§3.1 #5: read the inner_train patient IDs from the outer-test split
    CSV and return their clinical rows.  Used by ``evaluate_outer_test``
    to derive the survival reference without loading the WSI features.
    """
    split_path = os.path.join(
        dataset_factory.data_path,
        "splits", dataset_factory.which_splits, dataset_factory.study,
        f"fold_{fold}.csv",
    )
    split_df = pd.read_csv(split_path)
    if "inner_train" not in split_df.columns:
        raise KeyError(
            f"inner_train column not found in {split_path}; cannot derive "
            f"survival reference for outer-test evaluation"
        )
    inner_train_ids = split_df["inner_train"].dropna().astype(str).tolist()
    clinical = dataset_factory.clinical_df
    inner_train_labels = clinical[clinical["case id"].isin(inner_train_ids)].reset_index(drop=True)
    if len(inner_train_labels) == 0:
        raise ValueError(
            f"inner_train split resolved to 0 patients from {split_path}; "
            "check the split generation parameters"
        )
    return inner_train_labels


def evaluate(args, dataset_factory, model, loader, loss_fn, survival_train=None):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.eval()

    total_loss = 0.0
    v22_monitoring = _v22_monitoring_enabled(args)
    monitoring = _PatientWeightedMonitoring() if v22_monitoring else None
    seen_samples = 0
    if v22_monitoring:
        model.last_evaluation_monitoring_metrics = {}
        _validate_v22_evaluation_loader(loader)
    all_risk_scores, all_risk_by_bin, all_censorships, all_event_times = [], [], [], []
    all_logits, all_case_ids = [], []
    case_ids = loader.dataset.label_df["case id"]
    count = 0

    with torch.no_grad():
        for batch_idx, data in enumerate(loader):
            if data is None:
                continue
            if v22_monitoring:
                model.last_monitoring_metrics = {}
                model.last_monitoring_metric_weights = {}
            out, y_disc, event_time, c = _forward_training_batch(args, model, data, device, test=True)
            logits, _ = out

            if args.bag_loss == "cox_surv":
                loss = loss_fn(logits, event_time, c)
            elif args.bag_loss == "nll_surv":
                loss = loss_fn(logits, y_disc, event_time, c)
            else:
                raise ValueError(f"Loss not impl: {args.bag_loss}")

            total_loss += loss.item()
            batch_samples = int(y_disc.shape[0])
            if v22_monitoring:
                seen_samples += batch_samples
                monitoring.add(getattr(model, "last_monitoring_metrics", {}), batch_samples,
                               excluded={"global_nll", "auxiliary_total"},
                               metric_weights=getattr(model, "last_monitoring_metric_weights", {}))
            risk, risk_by_bin = _calculate_risk(logits)
            all_risk_by_bin.append(risk_by_bin)
            all_risk_scores, all_censorships, all_event_times = _update_arrays(
                all_risk_scores, all_censorships, all_event_times,
                event_time, c, risk, data
            )
            all_logits.append(logits.detach().cpu().numpy())
            if _v23_enabled(args):
                if len(data["patient_ids"]) != batch_samples:
                    raise ValueError("DCT v2.3 batch patient IDs do not match surviving samples")
                all_case_ids.extend(data["patient_ids"])
            elif v22_monitoring:
                all_case_ids.append(case_ids.values[batch_idx])
            else:
                all_case_ids.append(case_ids.values[count])
                count += 1

    if v22_monitoring:
        if seen_samples == 0:
            raise ValueError("DCT v2.2 evaluation processed no patients")
        total_loss /= seen_samples
        model.last_evaluation_monitoring_metrics = monitoring.means()
        model.last_evaluation_monitoring_metrics.update({
            "main_nll": total_loss,
            "patient_count": seen_samples,
        })
    else:
        total_loss /= max(len(loader.dataset), 1)
    all_risk_scores = np.concatenate(all_risk_scores, axis=0)
    all_censorships = np.concatenate(all_censorships, axis=0)
    all_event_times = np.concatenate(all_event_times, axis=0)
    all_logits = np.concatenate(all_logits, axis=0)
    all_risk_by_bin = np.concatenate(all_risk_by_bin, axis=0)

    patient_results = {}
    for i in range(len(all_case_ids)):
        cid = all_case_ids[i]
        patient_results[cid] = {
            "risk": all_risk_scores[i],
            "censor": all_censorships[i],
            "time": all_event_times[i],
            "logits": all_logits[i],
        }

    metric_error_path = os.path.join(
        args.results_dir,
        f"metric_diagnostics_fold{getattr(args, 'cur_fold', 'unknown')}.log",
    )
    c_index, c_index_ipcw, BS, IBS, iauc = _calculate_metrics(
        loader, dataset_factory, survival_train,
        all_risk_scores, all_censorships, all_event_times, all_risk_by_bin,
        metric_error_path=metric_error_path,
    )
    return patient_results, c_index, c_index_ipcw, BS, IBS, iauc, total_loss


# ============================================================
# 鏁存姌璁粌 + 璇勪及
# ============================================================

def train_one_fold(args, dataset_factory, fold, log_file):
    print(f"\n{'=' * 60}\n[Fold {fold}] start\n{'=' * 60}")
    safe_write_line(log_file, f"\n=== Fold {fold} start ===")
    ensure_min_free_space(args.results_dir, args.min_free_space_gb, f"Fold {fold} 寮€濮嬪墠")

    args.cur_fold = fold

    train_data, val_data, train_loader, val_loader = get_split(args, dataset_factory, fold)
    train_evaluation_loader = None
    if _v22_monitoring_enabled(args) and bool(getattr(args, "dct_v22_evaluate_train", True)):
        train_evaluation_loader = _build_v22_train_evaluation_loader(args, train_data)
    train_events = int((train_data.label_df[dataset_factory.censorship_var] < 0.5).sum())
    val_events = int((val_data.label_df[dataset_factory.censorship_var] < 0.5).sum())
    train_bins = train_data.label_df["label"].value_counts().sort_index().to_dict()
    val_bins = val_data.label_df["label"].value_counts().sort_index().to_dict()
    safe_write_line(
        log_file,
        f"[data] train_events={train_events} val_events={val_events} "
        f"train_bins={train_bins} val_bins={val_bins} "
        f"binning_mode={getattr(args, 'binning_mode', 'global_qcut')} "
        f"fit_bins_on_train={bool(getattr(args, 'fit_bins_on_train', False))} "
        f"event_sampling_fraction={float(getattr(args, 'event_sampling_fraction', 0.0) or 0.0):.3f}",
    )
    model = init_model_for_method(args, dataset_factory)
    if _v23_enabled(args) and args._dct_v23_gain_payload is not None:
        model.bind_gain_targets(*args._dct_v23_gain_payload)
    if hasattr(model, "configure_train_reference"):
        # DCT v3 fits stage edges and censoring weights strictly from this fold's
        # training cases before validation is ever seen.
        train_labels = train_data.label_df
        model.configure_train_reference(
            train_labels[dataset_factory.label_col].to_numpy(),
            train_labels[dataset_factory.censorship_var].to_numpy(),
        )
    loss_fn = init_loss_function(args)
    optimizer = init_optimizer(args, model)
    scheduler = init_scheduler(args, optimizer)

    # Censoring/IPCW reference quantities must be fitted only from the current
    # training fold.  Validation labels are never part of the reference.
    survival_train = _extract_survival_metadata(dataset_factory, train_data.label_df)

    args.max_cindex = 0.0
    args.max_cindex_epoch = 0

    best_results = None
    final_metrics = None
    epoch_records = []

    # 瀹炴椂鍐?epoch 鏇茬嚎 (閬垮厤宕╂簝涓㈠け)
    epoch_csv = os.path.join(args.results_dir, f"epoch_curve_fold{fold}.csv")

    # 鐏垫椿鍋滄锛氭棭鍋?patience + 鎵嬪姩涓柇 (Ctrl-C) 瀹夊叏钀界洏
    es_patience = int(getattr(args, "early_stop_patience", 0))
    es_min_delta = float(getattr(args, "early_stop_min_delta", 0.0))
    es_metric = getattr(args, "early_stop_metric", "val_cindex")
    es_warmup = int(getattr(args, "early_stop_warmup", 0))
    early_stopper = EarlyStoppingController(
        patience=es_patience,
        min_delta=es_min_delta,
        warmup_epochs=es_warmup,
    )
    stopped_epoch = args.max_epochs - 1

    def _save_best(results, model, fold):
        if not safe_torch_save(
            model.state_dict(),
            os.path.join(args.results_dir, f"model_best_s{fold}.pth")
        ):
            raise OSError(f"Fold {fold}: best checkpoint was not saved")
        if not safe_pickle_dump(results, os.path.join(args.results_dir, f"split_{fold}_results.pkl")):
            raise OSError(f"Fold {fold}: best predictions were not saved")

    try:
        for epoch in range(args.max_epochs):
            train_diagnostics = train_one_epoch(
                args, epoch, model, train_loader, optimizer, scheduler, loss_fn, log_file
            )
            safe_flush(log_file)
            results, val_c, val_c_ipcw, val_BS, val_IBS, val_iauc, val_loss = evaluate(
                args, dataset_factory, model, val_loader, loss_fn, survival_train
            )
            if not np.isfinite(val_c) or not np.isfinite(val_loss):
                raise FloatingPointError(
                    f"Fold {fold} epoch {epoch}: nonfinite primary validation score or loss"
                )
            val_monitoring = dict(getattr(model, "last_evaluation_monitoring_metrics", {})) if _v22_monitoring_enabled(args) else {}
            train_evaluation_monitoring = {}
            if train_evaluation_loader is not None:
                train_evaluation_monitoring = _evaluate_v22_train_snapshot(
                    args, dataset_factory, model, train_evaluation_loader, loss_fn, survival_train
                )
            msg = (f"[Epoch {epoch}] val cindex={val_c:.4f} ipcw={val_c_ipcw:.4f} "
                   f"IBS={val_IBS:.4f} iauc={val_iauc:.4f}")
            print(msg)
            safe_write_line(log_file, msg)
            safe_flush(log_file)
            epoch_records.append({
                'epoch': epoch,
                'val_cindex': val_c,
                'val_cindex_ipcw': val_c_ipcw,
                'val_IBS': val_IBS,
                'val_iauc': val_iauc,
                'val_loss': val_loss,
                **{f'train_{name}': value for name, value in train_diagnostics.items()},
                **{f'val_{name}': value for name, value in val_monitoring.items()},
                **{f'train_eval_{name}': value for name, value in train_evaluation_monitoring.items()},
            })
            ensure_min_free_space(args.results_dir, args.min_free_space_gb, f"Fold {fold} epoch {epoch} before write")
            # 姣忎釜 epoch 閮借鐩栧啓涓€娆?csv (閬垮厤宕╂簝涓㈠け鏇茬嚎)
            if not safe_to_csv(epoch_records, epoch_csv):
                raise OSError(f"Fold {fold}: epoch curve was not saved")

            # Keep the earliest checkpoint when a discretised C-index ties.
            # Replacing it with a later equal score previously selected a more
            # overfit model (for example DCT fold0 epoch 29 over epoch 4).
            if final_metrics is None or val_c > args.max_cindex:
                args.max_cindex = val_c
                args.max_cindex_epoch = epoch
                best_results = results
                _save_best(results, model, fold)
                final_metrics = (val_c, val_c_ipcw, val_BS, val_IBS, val_iauc, val_loss)

            # ---- 鏃╁仠鍒ゅ畾锛坧atience>0 鏃跺惎鐢紝涓旇繃浜?warmup锛?---
            if es_patience > 0:
                cur = {'val_cindex': val_c, 'val_cindex_ipcw': val_c_ipcw,
                       'val_iauc': val_iauc}.get(es_metric, val_c)
                if early_stopper.update(epoch, cur):
                    stopped_epoch = epoch
                    msg = (
                        f"[Fold {fold}] early stop @epoch {epoch} "
                        f"({es_metric} did not improve for {es_patience} epochs)"
                    )
                    print(msg)
                    safe_write_line(log_file, msg)
                    break
    except KeyboardInterrupt:
        stopped_epoch = len(epoch_records) - 1
        msg = (
            f"[Fold {fold}] interrupted @epoch {stopped_epoch}; "
            f"best cindex={args.max_cindex:.4f} @epoch {args.max_cindex_epoch} was preserved"
        )
        print(msg)
        safe_write_line(log_file, msg)
        safe_flush(log_file)
        safe_to_csv(epoch_records, epoch_csv)
        raise

    msg = (f"[Fold {fold}] best cindex={args.max_cindex:.4f} "
           f"@epoch {args.max_cindex_epoch} (stopped @epoch {stopped_epoch})")
    print(msg)
    safe_write_line(log_file, msg)
    safe_flush(log_file)

    print(f"[Fold {fold}] epoch curve 宸蹭繚瀛? {epoch_csv}")

    # §3.1 #5: under outer_test, evaluate the inner-train best checkpoint
    # on the outer test cohort EXACTLY once.  The outer test never sees
    # training data and never participates in checkpoint selection.
    outer_test_metrics = None
    if getattr(args, "evaluation_protocol", "legacy_val") == "outer_test":
        best_ckpt_path = os.path.join(
            args.results_dir, f"model_best_s{fold}.pth"
        )
        if os.path.exists(best_ckpt_path):
            try:
                outer_test_metrics = evaluate_outer_test(
                    args=args,
                    dataset_factory=dataset_factory,
                    fold=fold,
                    model_state_path=best_ckpt_path,
                    log_file=log_file,
                )
            except Exception as exc:
                safe_write_line(
                    log_file,
                    f"[outer-test] fold={fold} evaluation FAILED: {exc!r}",
                )
                safe_flush(log_file)
                raise
        else:
            safe_write_line(
                log_file,
                f"[outer-test] fold={fold} skipped: best checkpoint not found "
                f"at {best_ckpt_path}",
            )
            raise FileNotFoundError(f"Fold {fold}: outer-test checkpoint missing: {best_ckpt_path}")

    # 娓呯悊
    del model, optimizer, scheduler, train_loader, val_loader
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    return best_results, final_metrics, outer_test_metrics


# ============================================================
# 涓诲叆鍙?# ============================================================

def _preflight_calibration_artifacts(args, folds):
    """Check required filenames before any patient data or run output is opened.

    This never generates a teacher table. Full train-only provenance is still
    checked by ``load_calibration`` against each fold's actual patients.
    """
    from pathlib import Path

    if not folds:
        raise ValueError("No training folds selected")
    if int(args.max_epochs) < 1:
        raise ValueError("max_epochs must be positive")
    if not _v23_enabled(args) or getattr(args, "dct_v23_reconstruction_mode", "off") != "gain_calibrated":
        return
    directory = getattr(args, "dct_v23_calibration_dir", None)
    missing = [f"fold_{fold}.json" for fold in folds
               if not directory or not (Path(directory) / f"fold_{fold}.json").is_file()]
    if missing:
        raise FileNotFoundError(
            "gain_calibrated requires prepared train-only recovery gain tables; "
            f"missing in {directory!r}: {', '.join(missing)}. "
            "Generate the matching tables first with scripts/prepare_dct_v23_calibration.py "
            "--config <matching-config> --output-dir <calibration-dir> --folds "
            + " ".join(map(str, folds))
        )


def _validate_fold_completion(args, fold, results, metrics, outer_test_metrics):
    """Reject empty predictions, invalid primary metrics and partial artifacts."""
    if not isinstance(results, dict) or not results or metrics is None:
        raise RuntimeError(f"Fold {fold}: no completed validation result")
    if not np.isfinite(metrics[0]) or not np.isfinite(metrics[-1]):
        raise FloatingPointError(f"Fold {fold}: nonfinite primary validation score or loss")
    for case, prediction in results.items():
        if not isinstance(prediction, dict) or "risk" not in prediction:
            raise ValueError(f"Fold {fold}: missing risk for case {case}")
        for name in ("risk", "logits"):
            if name in prediction and not np.isfinite(np.asarray(prediction[name], dtype=float)).all():
                raise FloatingPointError(f"Fold {fold}: nonfinite {name} for case {case}")
    checkpoint = os.path.join(args.results_dir, f"model_best_s{fold}.pth")
    if not os.path.isfile(checkpoint) or os.path.getsize(checkpoint) == 0:
        raise FileNotFoundError(f"Fold {fold}: best checkpoint missing or empty: {checkpoint}")
    curve_path = os.path.join(args.results_dir, f"epoch_curve_fold{fold}.csv")
    curve = pd.read_csv(curve_path)
    if "epoch" not in curve or not len(curve) or not np.array_equal(curve["epoch"].to_numpy(), np.arange(len(curve))):
        raise ValueError(f"Fold {fold}: epoch curve is empty or noncontiguous")
    if len(curve) > int(args.max_epochs) or (
        int(getattr(args, "early_stop_patience", 0)) <= 0 and len(curve) != int(args.max_epochs)
    ):
        raise ValueError(f"Fold {fold}: epoch curve does not cover the requested training budget")
    if getattr(args, "evaluation_protocol", "legacy_val") == "outer_test":
        if outer_test_metrics is None:
            raise RuntimeError(f"Fold {fold}: outer-test evaluation did not complete")
        if not np.isfinite(outer_test_metrics[0]) or not np.isfinite(outer_test_metrics[-1]):
            raise FloatingPointError(f"Fold {fold}: nonfinite primary outer-test score or loss")


def run(args):
    if getattr(args, "dct_v313_revision", "legacy") == "repaired":
        from survot_rank.research.methods.legacy.experimental.dct_v313_transport_reconstruction.provenance import claim_repaired_results_root
        claim_repaired_results_root(args)
    folds = list(_get_start_end(args))
    _preflight_calibration_artifacts(args, folds)
    # 0. 鍏ㄥ眬绉嶅瓙澶嶄綅 (淇: --seed 涔嬪墠娌＄敤, 涓ゆ璁粌涓嶅彲澶嶇幇)
    seed = getattr(args, 'seed', 3)
    set_global_seed(seed)
    print(f"[run] set_global_seed({seed}) done")

    # 1. 鍑嗗瀹為獙鐩綍
    args.method = f"SurvOTRank_{args.survot_method}"
    # Ensure the experiment root exists before initializing this run.
    os.makedirs(args.results_dir, exist_ok=True)
    ensure_min_free_space(args.results_dir, args.min_free_space_gb, "before training start")
    args = _prepare_for_experiment(args)
    ensure_min_free_space(args.results_dir, args.min_free_space_gb, "after experiment directory initialization")

    # 2. 临床特征列解析
    clinical_feature_cols = None
    if getattr(args, "clinical_feature_cols", None):
        clinical_feature_cols = [c.strip() for c in args.clinical_feature_cols.split(",") if c.strip()]

    # 3. 数据集工厂 (一次构建，跨 fold 重用)
    dataset_factory = SurvivalDatasetFactory(
        study=args.study,
        data_path=args.data_path,
        rna_format=args.rna_format,
        signature=args.signature,
        n_bins=args.n_classes,
        label_col=args.label_col,
        num_genes=args.num_genes,
        num_patches=args.num_patches,
        clinical_feature_cols=clinical_feature_cols,
        binning_mode=getattr(args, "binning_mode", "global_qcut"),
        which_splits=getattr(args, "which_splits", "5fold"),
    )

    # 传递临床模态开关给模型
    if clinical_feature_cols and len(clinical_feature_cols) > 0:
        args.otehv2v2_use_clinical = True
        args.otehv2v2_clinical_feature_dim = len(clinical_feature_cols)

    # 4. 过滤掉 RNA 表里没有的 case_id (避免训练时 KeyError)
    if args.rna_format in ("Pathways", "RNASeq", "GeneEmbedding"):
        rna_cases = set(dataset_factory.gene_data_df.columns)
        before = len(dataset_factory.clinical_df)
        dataset_factory.clinical_df = dataset_factory.clinical_df[
            dataset_factory.clinical_df['case id'].isin(rna_cases)
        ].reset_index(drop=True)
        after = len(dataset_factory.clinical_df)
        if before != after:
            print(f"[filter] 杩囨护 RNA 缂哄け鐨?case: {before} -> {after}")

    # 4. log
    log_path = os.path.join(args.results_dir,
                            f"log_start_{args.k_start}_end_{args.k_end}.txt")
    log_file = open(log_path, "w", buffering=1)  # 琛岀紦鍐?
    all_metrics = []
    all_outer_test_metrics = []
    failed_folds = []
    for fold in folds:
        try:
            results, metrics, outer_test_metrics = train_one_fold(
                args, dataset_factory, fold, log_file
            )
            _validate_fold_completion(args, fold, results, metrics, outer_test_metrics)
            if not safe_pickle_dump(results, os.path.join(args.results_dir, f"split_{fold}_results_final.pkl")):
                raise OSError(f"Fold {fold}: final predictions were not saved")
            safe_flush(log_file)
        except Exception as e:
            failed_folds.append(fold)
            print(f"[ERROR] fold {fold} 澶辫触: {e}")
            safe_write_line(log_file, f"[ERROR] fold {fold} 澶辫触: {e}")
            safe_write_line(log_file, traceback.format_exc())
            safe_flush(log_file)
            continue
        except KeyboardInterrupt:
            safe_flush(log_file)
            log_file.close()
            raise

        if metrics is not None:
            all_metrics.append((fold, *metrics))
        if outer_test_metrics is not None:
            all_outer_test_metrics.append((fold, *outer_test_metrics))

    safe_flush(log_file)
    try:
        log_file.close()
    except OSError:
        pass

    # Summarize only folds that passed completion checks.
    if all_metrics:
        df = pd.DataFrame(all_metrics, columns=[
            "fold", "val_cindex", "val_cindex_ipcw", "val_BS",
            "val_IBS", "val_iauc", "val_loss"
        ])
        # 鍒犻櫎闈炴爣閲忓垪 (val_BS 鏄暟缁? 鏃犳硶 mean)
        if 'val_BS' in df.columns:
            df = df.drop(columns=['val_BS'])
        df.set_index("fold", inplace=True)
        try:
            means = df.mean(numeric_only=True)
            stds = df.std(numeric_only=True)
            df.loc["mean"] = means
            df.loc["std"] = stds
        except Exception as e:
            print(f"[summary] mean/std 澶辫触: {e}")
        save_name = "summary.csv" if len(all_metrics) == args.k and not failed_folds \
            else f"summary_partial_{args.k_start}_{args.k_end}.csv"
        if not safe_to_csv(df.reset_index(), os.path.join(args.results_dir, save_name)):
            raise OSError("Validation summary was not saved")
        print(f"\n[Summary]")
        print(df)

    # §3.1 #5: outer-test summary (only when evaluation_protocol=outer_test).
    # Written to a SEPARATE file so it is impossible to confuse with the
    # legacy_val summary above.  The two protocols MUST NOT be mixed.
    if all_outer_test_metrics and getattr(args, "evaluation_protocol", "legacy_val") == "outer_test":
        outer_df = pd.DataFrame(all_outer_test_metrics, columns=[
            "fold", "outer_test_cindex", "outer_test_cindex_ipcw", "outer_test_BS",
            "outer_test_IBS", "outer_test_iauc", "outer_test_loss"
        ])
        if 'outer_test_BS' in outer_df.columns:
            outer_df = outer_df.drop(columns=['outer_test_BS'])
        outer_df.set_index("fold", inplace=True)
        try:
            means = outer_df.mean(numeric_only=True)
            stds = outer_df.std(numeric_only=True)
            outer_df.loc["mean"] = means
            outer_df.loc["std"] = stds
        except Exception as e:
            print(f"[outer-test summary] mean/std 澶辫触: {e}")
        save_name = "summary_outer_test.csv" if len(all_outer_test_metrics) == args.k and not failed_folds \
            else f"summary_outer_test_partial_{args.k_start}_{args.k_end}.csv"
        if not safe_to_csv(outer_df.reset_index(), os.path.join(args.results_dir, save_name)):
            raise OSError("Outer-test summary was not saved")
        print(f"\n[Outer-Test Summary]")
        print(outer_df)

    if failed_folds:
        raise RuntimeError(
            f"Training failed for fold(s) {failed_folds}; "
            f"{len(all_metrics)}/{len(folds)} requested folds completed. "
            f"Completed outputs and failure details were retained under {args.results_dir}."
        )


def main():
    start = time.time()
    args = process_args_extended()
    # Respect CUDA_VISIBLE_DEVICES already set by the scheduler; fall
    # back to args.gpu when the env was not pre-set.  Without this
    # guard, two scheduler workers would each force GPU 0 and collide.
    if "CUDA_VISIBLE_DEVICES" not in os.environ:
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu
    run(args)
    end = time.time()
    print(f"\nDone. Time: {end - start:.1f}s")


if __name__ == "__main__":
    main()
