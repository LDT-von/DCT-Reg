"""Failure reporting contracts using only fake folds and synthetic records."""
from io import StringIO
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from survot_rank.training import train_runner as runner


def arguments(tmp_path, **updates):
    values = dict(survot_method="dct_v2", results_dir=str(tmp_path / "out"),
                  min_free_space_gb=0, study="synthetic", rna_format="fixture",
                  signature="fixture", n_classes=4, label_col="time", num_genes=None,
                  num_patches=8, k=2, k_start=0, k_end=2, seed=3, max_epochs=2,
                  data_path=str(tmp_path), evaluation_protocol="legacy_val",
                  early_stop_patience=0)
    values.update(updates)
    return SimpleNamespace(**values)


@pytest.fixture
def fake_run(tmp_path, monkeypatch):
    args = arguments(tmp_path)
    monkeypatch.setattr(runner, "set_global_seed", lambda seed: None)
    monkeypatch.setattr(runner, "ensure_min_free_space", lambda *a: None)
    monkeypatch.setattr(runner, "_prepare_for_experiment", lambda a: a)
    monkeypatch.setattr(runner, "SurvivalDatasetFactory", lambda **kw: object())
    monkeypatch.setattr(runner, "_get_start_end", lambda a: list(range(a.k_start, a.k_end)))

    def success(args, factory, fold, log):
        directory = Path(args.results_dir)
        (directory / f"model_best_s{fold}.pth").write_bytes(b"synthetic-checkpoint")
        pd.DataFrame({"epoch": range(args.max_epochs)}).to_csv(
            directory / f"epoch_curve_fold{fold}.csv", index=False)
        results = {"SYNTHETIC_CASE": {"risk": .2, "logits": np.array([.1, -.2])}}
        metrics = (.6 + .2 * fold, .6, None, .1, .6, 1.)
        outer = metrics if args.evaluation_protocol == "outer_test" else None
        return results, metrics, outer

    monkeypatch.setattr(runner, "train_one_fold", success)
    return args, success


@pytest.mark.parametrize("failures", [{0}, {0, 1}])
def test_any_failed_fold_makes_run_fail_and_keeps_completed_outputs(fake_run, monkeypatch, failures):
    args, success = fake_run

    def sometimes_fails(args, factory, fold, log):
        if fold in failures:
            raise FileNotFoundError(f"missing synthetic fold_{fold}.json")
        return success(args, factory, fold, log)

    monkeypatch.setattr(runner, "train_one_fold", sometimes_fails)
    with pytest.raises(RuntimeError, match="failed.*fold|fold.*failed"):
        runner.run(args)
    if 1 not in failures:
        assert (Path(args.results_dir) / "split_1_results_final.pkl").is_file()
        assert (Path(args.results_dir) / "summary_partial_0_2.csv").is_file()
    assert not (Path(args.results_dir) / "summary.csv").exists()
    assert "missing synthetic" in (Path(args.results_dir) / "log_start_0_end_2.txt").read_text()


@pytest.mark.parametrize("fault", ["no_result", "nan_score", "nan_risk", "missing_checkpoint", "short_curve", "missing_outer"])
def test_incomplete_or_nonfinite_fold_is_not_success(fake_run, monkeypatch, fault):
    args, success = fake_run
    args.k_end = 1
    if fault == "missing_outer":
        args.evaluation_protocol = "outer_test"

    def incomplete(args, factory, fold, log):
        results, metrics, outer = success(args, factory, fold, log)
        if fault == "no_result":
            return None, None, None
        if fault == "nan_score":
            metrics = (float("nan"), *metrics[1:])
        if fault == "nan_risk":
            results["SYNTHETIC_CASE"]["risk"] = float("nan")
        if fault == "missing_checkpoint":
            (Path(args.results_dir) / f"model_best_s{fold}.pth").unlink()
        if fault == "short_curve":
            pd.DataFrame({"epoch": [0]}).to_csv(Path(args.results_dir) / f"epoch_curve_fold{fold}.csv", index=False)
        if fault == "missing_outer":
            outer = None
        return results, metrics, outer

    monkeypatch.setattr(runner, "train_one_fold", incomplete)
    with pytest.raises(RuntimeError, match="failed.*fold|fold.*failed"):
        runner.run(args)


def test_failed_final_prediction_write_is_not_success(fake_run, monkeypatch):
    args, _ = fake_run
    monkeypatch.setattr(runner, "safe_pickle_dump", lambda *a: False)
    with pytest.raises(RuntimeError, match="failed.*fold|fold.*failed"):
        runner.run(args)


@pytest.mark.parametrize("protocol,name", [("legacy_val", "summary.csv"), ("outer_test", "summary_outer_test.csv")])
def test_summary_std_uses_only_real_folds(fake_run, protocol, name):
    args, _ = fake_run
    args.evaluation_protocol = protocol
    runner.run(args)
    frame = pd.read_csv(Path(args.results_dir) / name).set_index("fold")
    column = "outer_test_cindex" if protocol == "outer_test" else "val_cindex"
    assert frame.loc["mean", column] == pytest.approx(.7)
    assert frame.loc["std", column] == pytest.approx(np.std([.6, .8], ddof=1))


def test_missing_calibration_fails_before_data_or_output_initialization(tmp_path, monkeypatch):
    args = arguments(tmp_path, survot_method="dct_v23",
                     dct_v23_reconstruction_mode="gain_calibrated",
                     dct_v23_calibration_dir=str(tmp_path / "missing_calibration"))

    def forbidden(*a, **kw):
        pytest.fail("Missing calibration must fail before patient data or output initialization")

    monkeypatch.setattr(runner, "_prepare_for_experiment", forbidden)
    monkeypatch.setattr(runner, "SurvivalDatasetFactory", forbidden)
    monkeypatch.setattr(runner, "set_global_seed", lambda seed: None)
    monkeypatch.setattr(runner, "ensure_min_free_space", lambda *a: None)
    with pytest.raises(FileNotFoundError, match="prepare_dct_v23_calibration"):
        runner.run(args)
    assert not Path(args.results_dir).exists()


def test_calibration_preflight_only_checks_requested_folds(tmp_path):
    args = arguments(tmp_path, survot_method="dct_v23",
                     dct_v23_reconstruction_mode="gain_calibrated",
                     dct_v23_calibration_dir=str(tmp_path / "tables"))
    directory = Path(args.dct_v23_calibration_dir)
    directory.mkdir()
    (directory / "fold_2.json").write_text("{}")
    runner._preflight_calibration_artifacts(args, [2])
    with pytest.raises(FileNotFoundError, match="fold_0.json"):
        runner._preflight_calibration_artifacts(args, [0, 2])


@pytest.mark.parametrize("mode", ["off", "masked_plain"])
def test_noncalibrated_controls_do_not_require_gain_tables(tmp_path, mode):
    args = arguments(tmp_path, survot_method="dct_v23",
                     dct_v23_reconstruction_mode=mode, dct_v23_calibration_dir=None)
    runner._preflight_calibration_artifacts(args, [0, 1])


@pytest.mark.parametrize("mode", ["fold_failure", "missing_calibration"])
def test_failed_command_returns_nonzero_exit_code(tmp_path, mode):
    code = """
import sys
from pathlib import Path
from types import SimpleNamespace
from survot_rank.training import train_runner as r
args=SimpleNamespace(survot_method='dct_v2',results_dir=sys.argv[1],max_epochs=1,
 min_free_space_gb=0,study='SYNTHETIC',rna_format='fixture',signature='fixture',
 n_classes=4,label_col='time',num_genes=None,num_patches=8,data_path='unused',
 k=1,k_start=0,k_end=1,evaluation_protocol='legacy_val')
r.set_global_seed=lambda seed:None
r.ensure_min_free_space=lambda *a:None
r._get_start_end=lambda a:[0]
r._prepare_for_experiment=lambda a:a
r.SurvivalDatasetFactory=lambda **kw:object()
def fail(*a):raise ValueError('SYNTHETIC_FOLD_FAILURE')
r.train_one_fold=fail
if sys.argv[2]=='missing_calibration':
 args.survot_method='dct_v23'
 args.dct_v23_reconstruction_mode='gain_calibrated'
 args.dct_v23_calibration_dir=str(Path(sys.argv[1])/'absent')
r.run(args)
"""
    out = tmp_path / "command_out"
    result = subprocess.run([sys.executable, "-B", "-c", code, str(out), mode],
                            cwd=Path(__file__).resolve().parents[1], capture_output=True,
                            text=True, encoding="utf-8", timeout=60)
    assert result.returncode != 0
    expected = "SYNTHETIC_FOLD_FAILURE" if mode == "fold_failure" else "prepare_dct_v23_calibration"
    assert expected in result.stdout + result.stderr
    if mode == "missing_calibration":
        assert not out.exists()


def fake_fold(tmp_path, monkeypatch, *, protocol="legacy_val", score=.6):
    args = arguments(tmp_path, evaluation_protocol=protocol)
    Path(args.results_dir).mkdir()
    frame = pd.DataFrame({"case id": ["SYN_A", "SYN_B"], "event": [0., 1.], "label": [0, 1]})
    data = SimpleNamespace(label_df=frame)
    factory = SimpleNamespace(censorship_var="event")
    model = SimpleNamespace(state_dict=lambda: {})
    monkeypatch.setattr(runner, "get_split", lambda *a: (data, data, [], []))
    monkeypatch.setattr(runner, "ensure_min_free_space", lambda *a: None)
    monkeypatch.setattr(runner, "init_model_for_method", lambda *a: model)
    monkeypatch.setattr(runner, "init_loss_function", lambda *a: None)
    monkeypatch.setattr(runner, "init_optimizer", lambda *a: object())
    monkeypatch.setattr(runner, "init_scheduler", lambda *a: object())
    monkeypatch.setattr(runner, "_extract_survival_metadata", lambda *a: None)
    monkeypatch.setattr(runner, "train_one_epoch", lambda *a: {"loss": 1.})
    monkeypatch.setattr(runner, "evaluate", lambda *a: ({"SYN_A": {"risk": .2}}, score, .5, None, .1, .5, 1.))
    monkeypatch.setattr(runner.torch.cuda, "is_available", lambda: False)
    return args, factory


def test_zero_cindex_still_saves_first_valid_checkpoint(tmp_path, monkeypatch):
    args, factory = fake_fold(tmp_path, monkeypatch, score=0.)
    results, metrics, _ = runner.train_one_fold(args, factory, 0, StringIO())
    assert results and metrics[0] == 0.
    assert (Path(args.results_dir) / "model_best_s0.pth").is_file()


def test_interrupted_fold_propagates_interrupt(tmp_path, monkeypatch):
    args, factory = fake_fold(tmp_path, monkeypatch)

    def interrupt(*a):
        raise KeyboardInterrupt

    monkeypatch.setattr(runner, "train_one_epoch", interrupt)
    with pytest.raises(KeyboardInterrupt):
        runner.train_one_fold(args, factory, 0, StringIO())


def test_outer_test_failure_does_not_silently_complete_fold(tmp_path, monkeypatch):
    args, factory = fake_fold(tmp_path, monkeypatch, protocol="outer_test")

    def fail(**kwargs):
        raise ValueError("synthetic outer-test evaluation failure")

    monkeypatch.setattr(runner, "evaluate_outer_test", fail)
    with pytest.raises(ValueError, match="synthetic outer-test"):
        runner.train_one_fold(args, factory, 0, StringIO())


@pytest.mark.parametrize("writer", ["safe_torch_save", "safe_to_csv"])
def test_required_fold_artifact_write_failure_propagates(tmp_path, monkeypatch, writer):
    args, factory = fake_fold(tmp_path, monkeypatch)
    monkeypatch.setattr(runner, writer, lambda *a: False)
    with pytest.raises(OSError):
        runner.train_one_fold(args, factory, 0, StringIO())
